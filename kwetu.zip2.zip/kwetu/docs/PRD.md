# MASTER PRODUCT REQUIREMENTS DOCUMENT

**PROJECT: KWETU APP**

## 1. PRODUCT VISION

Build a modern, mobile-first, location-driven social and commerce platform that connects people, service providers, businesses, event organisers and transport operators within their local communities.

The platform helps people discover what is happening around them, find people and services, express interest, make bookings, purchase tickets, request transport and participate in real-world experiences.

It is not simply a social media application, dating application, event application or service directory.

It combines social discovery with real-time availability, bookings, transactions, event promotion and local service fulfilment.

**Tagline**

"Your city, your people, your plans."

**Core philosophy**

People should be able to discover opportunities around them and act on them immediately.

A person should be able to:

- Find someone to spend an evening with.
- Discover a massage provider and book an appointment.
- Find a club hosting karaoke tonight.
- Discover a party, see who is interested and buy a ticket.
- Promote their own event and reach local customers.
- Find nearby transport.
- Offer their own services and attract paying customers.
- Discover local experiences they didn't previously know existed.

The platform should connect these activities through one social network, one identity system, one discovery engine and one underlying transaction infrastructure.

## 2. THE FIVE CONNECTED PILLARS

The platform has five major pillars.

They must feel like parts of one ecosystem, not five unrelated applications.

### PILLAR 1: COMPANIONSHIP

This is the original inspiration behind the platform and an important part of its identity.

**The problem:**

People going out often spend money, time and effort trying to find company without clear expectations or reliable arrangements.

People who offer companionship may spend hours in nightlife venues waiting for customers, negotiating informally or being approached by people whose intentions are unclear.

The platform creates a more structured way for consenting adults to discover and book companionship.

**Features:**

**Companion profiles**

- Profile photograph and cover image.
- Display name.
- Age verification where required.
- General location.
- Short biography.
- Interests and personality.
- Languages spoken.
- Services or companionship categories offered.
- Pricing and booking conditions.
- Availability status.
- Hosting preferences.
- Reviews and verified booking history.
- Optional photos and additional profile information.

**Availability management**

Providers must be able to switch between:

- Available now.
- Available later.
- Busy.
- Unavailable.

They should be able to define available hours and appointment slots.

**Discovery**

Customers can browse:

- Available companions nearby.
- Companions at a particular opted-in venue.
- Companions available for a particular time.
- Companions within a selected price range.
- Companions offering particular experiences.

Filters should include location, availability, category, price and relevant preferences.

**Booking system**

A customer should be able to:

1. Open a provider's profile.
2. Review services, prices and conditions.
3. Select a date and time.
4. Choose a meeting arrangement where offered.
5. Send a booking request.
6. Receive acceptance, rejection or an alternative proposal.
7. Confirm and pay where payment is required.
8. Receive booking details.
9. Confirm arrival and completion separately.
10. Submit a review after the booking.

**Waiting lists and queues**

If a provider is busy, customers should be able to join a queue or request notification when the provider becomes available.

The provider must be able to:

- See their waiting customers.
- See when each person joined.
- Accept the next customer.
- Skip or decline a request.
- Pause their queue.
- Set maximum queue capacity.
- Notify waiting customers when a slot opens.

Customers should see their queue position and estimated waiting time only when the provider has supplied enough information to calculate it.

**Hosting and meeting arrangements**

Providers may indicate whether they:

- Host customers at their approved business location.
- Meet customers at mutually agreed public venues.
- Travel to customers where appropriate.

Never expose a private residential address publicly.

**Same-venue discovery**

A user attending a participating club or venue can voluntarily opt into discovery at that venue.

Other opted-in users can discover them through a dedicated venue discovery experience.

Presence must not automatically mean availability. Users must explicitly choose to be discoverable and separately indicate whether they are open to bookings.

Location sharing must be temporary, consent-based and limited to what is necessary.

Do not build a system that continuously tracks people without their permission.

**Important:**
Companionship does not automatically mean sexual services. Make the categories, descriptions and booking conditions explicit. Users must be adults for adult companionship features. Do not imply that payment purchases consent or guarantees intimacy.

### PILLAR 2: EXPERIENCES

This section helps people discover interesting things to do around them.

It should contain:

- Clubs and lounges.
- Restaurants.
- Karaoke nights.
- Pool parties.
- Live music.
- Sports screenings.
- Festivals.
- Concerts.
- Outdoor activities.
- Excursions.
- Social mixers.
- Wellness experiences.
- Special promotions.
- Local attractions.

Each experience should have a dedicated page with:

- Name.
- Cover image or video.
- Description.
- Location.
- Date and time.
- Organiser or business.
- Price, if applicable.
- Booking or ticket link.
- Interested people.
- Reviews where appropriate.
- Discussion and sharing.
- Directions or map location.

Users should be able to:

- Save an experience.
- Share it.
- Express interest.
- RSVP where supported.
- Purchase a ticket.
- Invite friends.
- Discuss the experience.

Experiences should be discoverable based on location, date, category and popularity.

Businesses should be able to publish recurring activities such as Wednesday karaoke without creating an entirely new business profile every time.

### PILLAR 3: EVENTS AND TICKETING

This pillar gives anyone the ability to advertise and sell tickets for events.

The platform must not be restricted to large event companies.

An individual organising a birthday, graduation party, pool party, concert or private function should be able to create an organiser account and publish an event.

**Event creation**

Allow organisers to:

- Enter event name.
- Upload poster, photographs and videos.
- Write event description.
- Select category.
- Specify venue.
- Set date and time.
- Add event contact information.
- Set ticket types and prices.
- Define ticket quantities.
- Set ticket sales opening and closing times.
- Publish, edit, pause or cancel an event.

Basic event publishing and advertising should be free.

The platform should welcome organisers of all sizes.

**Ticket sales**

Support:

- Free tickets.
- Early-bird tickets.
- Regular tickets.
- VIP tickets.
- Multiple ticket categories.
- Limited ticket quantities.
- Purchase confirmation.
- Digital ticket delivery.

Every ticket must have a unique QR code or barcode linked to a unique ticket record.

**Door validation**

Build a dedicated event check-in interface.

Organisers and authorised gate staff should be able to:

- Scan a QR code.
- Validate the ticket.
- See the ticket category.
- See whether the ticket has already been used.
- Mark the ticket as checked in.
- Detect duplicate scans.
- View attendance counts.

Include a secure offline-capable scanning design where possible. Offline validation must use a securely downloaded event ticket list and reconcile scans when connectivity returns. Clearly flag potential duplicate or conflicting offline scans.

**Organiser dashboard**

Each organiser should have a dashboard showing:

- Total tickets issued.
- Tickets sold.
- Revenue.
- Remaining inventory.
- Free registrations.
- Event page views.
- Shares.
- Interested users.
- Confirmed attendees.
- Actual check-ins.
- Sales by ticket category.
- Sales over time.

Clearly distinguish views, interest, purchases and actual attendance.

**Event advertising and reach**

Events should receive organic discovery through:

- Nearby event recommendations.
- Relevant category feeds.
- Local trending events.
- User interests.
- Social sharing.
- Event discussions.
- Notifications to interested users.

Provide optional paid promotion tools, but do not make payment mandatory for basic listing.

**Trust and impersonation prevention**

Organisers should have verified profiles and a public event identity.

Display:

- Verified organiser status.
- Official event page.
- Official ticket purchasing destination.
- Ticket validity.
- Event updates and cancellation notices.

Do not allow an unofficial account to appear as the official organiser.

Create an event reporting process for impersonation, fake events and ticket fraud.

**Payments and settlement**

Design the payment system so that customer funds are handled through a suitable licensed payment provider.

Do not assume the platform can legally operate its own escrow service or hold customer funds without the necessary approvals.

Include configurable:

- Payment confirmation.
- Organiser settlement rules.
- Refund policies.
- Cancellation handling.
- Postponement handling.
- Transaction records.
- Platform commission.

Never show a payment as successful until the payment provider confirms it.

### PILLAR 4: WELLNESS

Create a marketplace for legitimate wellness and personal-care services.

Examples:

- Massage.
- Spa treatments.
- Beauty services.
- Relaxation services.
- Personal care.
- Other approved wellness experiences.

Providers should be able to:

- Create service listings.
- Upload photographs.
- Describe services.
- Set prices.
- Set service duration.
- Set operating hours.
- Define their service area.
- Accept bookings.
- Manage appointments.
- Manage waiting lists.
- Receive customer reviews.

Customers should be able to:

- Search nearby providers.
- Compare services and prices.
- View availability.
- Book appointments.
- Request mobile services where offered.
- Track booking status.
- Leave reviews.

Provider verification and appropriate qualifications should be supported.

Clearly distinguish legitimate wellness services from services that are not permitted on the platform.

### PILLAR 5: TRANSPORT AND MOBILITY

This pillar connects customers with available local transport operators.

It should work for towns where conventional taxi applications may have limited coverage.

Initial provider categories:

- Boda boda operators.
- Private drivers.
- Cars.
- Local transport providers.
- Designated drivers where legally and operationally supported.

**Driver profiles**

- Name.
- Photograph.
- Transport category.
- Vehicle details.
- Registration details where applicable.
- Operating area.
- Verification status.
- Availability.
- Ratings.

**Availability**

Drivers should be able to switch between:

- Online.
- Offline.
- Busy.

**Ride request workflow**

1. Customer selects transport.
2. Customer enters pickup location.
3. Customer enters destination.
4. Platform identifies available nearby operators.
5. Operators receive request notifications.
6. An operator accepts or declines.
7. Customer sees the accepted operator and relevant vehicle details.
8. The trip is marked as started.
9. The trip is marked as completed.
10. Customer can rate the service.

For the initial version, allow a simple request-and-accept workflow rather than attempting to build a sophisticated Uber-level routing system immediately.

Include fare estimates or operator-defined fares where supported.

Never invent a driver's location or show a driver as available when they are offline.

## 3. THE SOCIAL NETWORK

The five pillars must be connected by a shared social experience.

Build a central home feed.

This is not intended to copy Facebook. Its purpose is to help users discover and participate in local activity.

The feed should combine:

- Posts from people and businesses they follow.
- Local experiences.
- Upcoming events.
- Companionship availability.
- Service announcements.
- Local promotions.
- Relevant discussions.
- Popular activities nearby.

Users should be able to:

- Create posts.
- Upload photographs and videos.
- Like posts.
- Comment.
- Share.
- Follow users and businesses.
- Save posts.
- Report inappropriate content.

Posts should support location tagging where the author chooses to include it.

Include a clear distinction between ordinary social posts, service listings, event listings and paid promotions.

Do not make the feed an unfiltered stream of advertisements.

Use relevance, recency, location and user interests to determine discovery.

## 4. LOCATION-BASED DISCOVERY

Location is a major part of the product.

The platform should allow users to discover relevant people, providers, businesses and experiences around their chosen location.

Create these discovery experiences:

**Around Me**

Shows relevant local activity, services, businesses and events.

**Same Venue**

Shows people who have voluntarily opted into discovery at the same participating venue.

**Available Now**

Shows providers and services currently accepting requests.

**Explore**

Allows browsing by category and location.

**Search**

A global search system supporting:

- People.
- Companions.
- Wellness providers.
- Businesses.
- Events.
- Experiences.
- Transport operators.

Users must be able to change their search location manually.

Support location permissions gracefully. If a user declines location access, they should still be able to search by town, neighbourhood or selected location.

Never expose private live locations without explicit permission.

## 5. USER ACCOUNTS AND ROLES

A single person may use the platform in multiple capacities.

Do not create five separate accounts for five different activities.

Create one user identity with the ability to activate different account capabilities.

**Supported roles and capabilities:**

**Regular user**

- Browse.
- Post.
- Follow.
- Discover.
- Book.
- Buy tickets.
- Request transport.
- Review completed transactions.

**Service provider**

- Publish services.
- Set availability.
- Manage bookings.
- Manage queues.
- Receive notifications.
- View earnings and performance.

**Companion provider**

- Create a companionship profile.
- Set availability and booking conditions.
- Accept requests.
- Manage queues.
- Control discovery visibility.

**Business owner**

- Create a business page.
- Publish experiences.
- Advertise promotions.
- Publish recurring activities.
- Manage bookings.

**Event organiser**

- Create events.
- Sell tickets.
- Manage customers.
- Scan tickets.
- View reports.

**Transport operator**

- Create a transport profile.
- Set availability.
- Receive ride requests.
- Manage trips.

**Administrator**

- Manage users.
- Review reports.
- Verify accounts.
- Moderate listings.
- Monitor transactions.
- Manage categories and platform settings.

A user should be able to switch between their personal account and business/provider dashboard without creating another login.

## 6. BOOKING AND QUEUE ENGINE

Build a reusable booking system that can serve companionship, wellness and other appointment-based services.

**Booking statuses:**

- Pending.
- Accepted.
- Declined.
- Awaiting payment.
- Confirmed.
- In progress.
- Completed.
- Cancelled.
- Disputed.
- Refunded.

The booking system must prevent double-booking of unavailable time slots.

Providers must be able to set:

- Working hours.
- Appointment duration.
- Breaks.
- Booking notice periods.
- Maximum daily bookings.
- Cancellation rules.
- Queue capacity.

Customers should receive booking notifications and status updates.

Build queue management separately from ordinary bookings but connect them to provider availability.

## 7. PAYMENTS AND REVENUE MODEL

Build a central transaction infrastructure that supports the different pillars.

**Potential revenue sources:**

1. Commission on completed bookings.
2. Commission on ticket sales.
3. Optional paid event promotion.
4. Optional business promotion.
5. Business subscription plans for advanced tools.
6. Future premium consumer features where justified.

Basic social participation and basic event publishing should remain free.

Build:

- Transaction history.
- Payment status.
- Commission records.
- Provider earnings.
- Organiser earnings.
- Refund records.
- Settlement records.
- Payment failure handling.

Use Kenya-oriented payment architecture, with M-Pesa integration designed as a configurable provider integration.

Do not hardcode API credentials.

Create a payment abstraction so additional providers can be added later.

For the first build, provide a clearly labelled sandbox/demo payment mode if real credentials are unavailable.

Do not pretend that a simulated transaction is a real payment.

## 8. NOTIFICATIONS

Build an in-app notification centre.

Notifications should include:

- New booking request.
- Booking accepted.
- Booking declined.
- Queue position updated.
- Provider becomes available.
- New ride request.
- Ride accepted.
- Event published.
- Event reminder.
- Ticket purchase confirmation.
- Event cancellation.
- New follower.
- Relevant local activity.
- Business enquiry.

Design the notification architecture to support future push notifications, email and SMS.

Allow users to control notification preferences.

Avoid sending irrelevant mass notifications.

## 9. REVIEWS AND REPUTATION

Build a reputation system based on genuine platform interactions.

Users should only be able to leave verified transaction reviews when the associated booking, trip or event attendance has been completed or appropriately verified.

Support:

- Written reviews.
- Star ratings.
- Provider response.
- Report review.
- Review moderation.

Keep reputation scores separate for different activities where appropriate.

Do not let someone buy a good rating or easily manufacture reviews through repeated fake accounts.

## 10. MESSAGING

Create an internal messaging system.

Users should be able to communicate with:

- Other users.
- Companions.
- Service providers.
- Businesses.
- Event organisers.

Messaging should support:

- Text.
- Images.
- Booking references.
- Event references.
- Service references.
- Blocking.
- Reporting.
- Basic spam controls.

Where possible, bookings should be initiated through structured booking requests rather than requiring users to negotiate everything through chat.

## 11. TRUST, SAFETY AND MODERATION

This platform facilitates real-world interactions. Safety must be built into its architecture.

Implement:

- Email and phone verification.
- Appropriate identity verification for higher-risk provider roles.
- Age restrictions for adult-oriented features.
- Verified business and organiser profiles.
- Reporting and blocking.
- Admin moderation queues.
- Suspicious activity flags.
- Booking dispute management.
- Transaction audit logs.
- Privacy controls.
- Consent-based location sharing.
- Emergency and safety guidance for in-person bookings.

Never display a user's private address or continuous location to other users.

Do not make a booking payment a guarantee of personal access, intimacy or consent.

Allow users to cancel or seek assistance when they feel unsafe.

Create clear terms, privacy and community-guideline pages with placeholders for professional legal review.

## 12. ADMINISTRATION DASHBOARD

Build a comprehensive administrative dashboard.

Administrators should be able to view:

**Platform overview**

- Total users.
- Active users.
- New registrations.
- Active providers.
- Published events.
- Active businesses.
- Bookings.
- Ticket sales.
- Ride requests.
- Transaction volume.
- Platform revenue.

**User management**

- Search users.
- View profiles.
- Verify accounts.
- Suspend accounts.
- Handle appeals.
- Review reports.

**Content management**

- Review posts.
- Review listings.
- Review events.
- Remove fraudulent content.
- Manage categories.

**Transaction management**

- View transactions.
- Track payment statuses.
- View commissions.
- Review refunds.
- Handle disputes.

**Event oversight**

- Review organisers.
- Investigate impersonation.
- Review reported events.
- Monitor ticketing activity.

**Analytics**

- Activity by town.
- Popular categories.
- Booking conversion.
- Event engagement.
- Ticket conversion.
- Provider availability.
- Customer retention.

## 13. DESIGN AND USER EXPERIENCE

The application must feel like a premium, modern Kenyan technology product.

**Design direction:**

- Mobile-first.
- Clean and modern.
- Visually engaging.
- Easy to navigate.
- Fast-loading.
- Professional rather than overly corporate.
- Suitable for nightlife, everyday services and business transactions.

Use a consistent design system.

**Suggested palette:**

- Deep midnight navy as the main dark colour.
- Electric purple as a primary accent.
- Turquoise as a secondary accent.
- White and soft neutral backgrounds.
- Carefully selected gradients for promotional content.

Do not make the application look like a generic admin dashboard.

Use attractive photography, strong typography, clean cards and clear visual hierarchy.

Avoid excessive gradients, excessive rounded cards and clutter.

Build responsive layouts for mobile, tablet and desktop.

**Main navigation**

On mobile, use a persistent bottom navigation bar:

1. Home
2. Explore
3. Create
4. Activity
5. Profile

The Create action should open a menu allowing users to create:

- A social post.
- A service listing.
- An experience.
- An event.
- A business page.

Provider and business dashboards should be accessible from the profile area.

**Main home screen**

The home screen should include:

- Location selector.
- Search bar.
- Discoverable category shortcuts.
- Available now section.
- Nearby experiences.
- Upcoming events.
- Local social feed.
- Relevant recommendations.

Do not overload the home screen. Use meaningful sections and progressive discovery.

## 14. DATABASE AND BACKEND ARCHITECTURE

Use Supabase as the preferred backend.

Implement:

- Authentication.
- PostgreSQL database.
- Row Level Security.
- File storage.
- Realtime subscriptions where appropriate.
- Edge Functions for sensitive server-side operations.

Design a relational database covering at least:

- users
- profiles
- user_roles
- businesses
- business_members
- provider_profiles
- service_categories
- services
- availability_schedules
- availability_exceptions
- bookings
- booking_participants
- queues
- queue_entries
- events
- event_categories
- event_ticket_types
- tickets
- ticket_scans
- experiences
- posts
- comments
- reactions
- follows
- venue_check_ins
- location_preferences
- conversations
- messages
- ride_requests
- trips
- reviews
- notifications
- transactions
- payment_records
- commission_records
- refunds
- reports
- verification_records
- promotions
- audit_logs

Use appropriate foreign keys, indexes, constraints and timestamps.

Implement strict Row Level Security policies.

Users must not be able to access another user's private bookings, messages, identity documents or payment information.

Sensitive operations such as payment confirmation, ticket issuance, ticket validation, commission calculation and role verification must be handled securely on the backend.

Do not rely on frontend-only checks for security.

## 15. INITIAL LAUNCH MARKET

Configure Bungoma, Kenya, as the initial default market.

However, the architecture must support multiple towns and cities.

Include:

- Town selection.
- Neighbourhood selection where appropriate.
- Location-based discovery.
- KSh pricing.
- Kenya-oriented phone number handling.
- M-Pesa integration readiness.
- Local business and provider categories.

Do not hardcode Bungoma into the entire application.

## 16. BUILD REQUIREMENTS

Build the actual application, not just a landing page or visual prototype.

Start with:

- A polished landing page.
- Registration and login.
- User profiles.
- Home feed.
- Explore and search.
- Companionship discovery.
- Provider profiles.
- Booking requests.
- Availability management.
- Waiting lists.
- Experiences.
- Event publishing.
- Ticket purchasing and QR ticket generation.
- Event check-in.
- Business profiles.
- Wellness listings.
- Transport requests.
- Messaging.
- Notifications.
- Admin dashboard.

All main navigation items must lead to functioning pages.

All forms must validate input.

All buttons must perform their stated actions.

All important records must persist in the database.

Use realistic demo data to demonstrate the full experience, but clearly distinguish demo data from real users and transactions.

Create a development checklist showing:

- Completed features.
- Incomplete features.
- Features requiring API credentials.
- Features requiring external verification.
- Features requiring legal or regulatory review.

Do not claim a feature is production-ready if it is only simulated.

## 17. ACCEPTANCE TESTS

The application should pass these end-to-end tests:

**TEST A: COMPANIONSHIP**

A provider creates a profile, lists a service, sets availability and publishes it.

A customer discovers the provider, submits a booking request, receives acceptance, confirms the booking and completes the process.

**TEST B: QUEUE**

A provider becomes busy.

A second customer joins the queue.

The provider finishes the current booking and makes a slot available.

The next customer receives a notification and can request the slot.

**TEST C: EVENT ORGANISER**

An organiser registers, creates an event, uploads a poster, creates ticket categories and publishes the event.

A customer discovers the event, purchases a ticket and receives a unique QR code.

**TEST D: EVENT GATE**

An authorised gate operator scans the ticket.

The system validates it and marks it used.

A second scan of the same ticket is rejected as a duplicate.

**TEST E: CLUB OWNER**

A club creates a business profile and publishes recurring Wednesday karaoke.

Nearby users discover the event, express interest, share it and RSVP.

The club owner sees reach, interest and attendance information separately.

**TEST F: BODA OPERATOR**

A driver creates a profile, completes the required verification and switches availability on.

A nearby customer submits a ride request.

The driver receives a notification and accepts it.

The customer sees the accepted operator and ride status.

**TEST G: ADMINISTRATOR**

An administrator logs in and can review users, verify providers, investigate reports, manage listings and inspect transaction records.

## 18. IMPORTANT PRODUCT PRINCIPLES

1. One platform, one user identity.
2. Five interconnected pillars.
3. Social discovery must generate real-world opportunities.
4. Availability must be meaningful and accurate.
5. Customers must be able to take action, not merely browse.
6. Providers must have tools to convert attention into paying customers.
7. Organisers must have access to measurable local promotion.
8. Businesses must be able to attract nearby customers.
9. The platform must work for small independent operators, not only established companies.
10. Basic participation and event publishing should be accessible.
11. Payments, bookings, ticketing and reputation must be trustworthy.
12. Privacy and consent must be respected throughout.

The ultimate goal is to build a local network where demand and supply can find one another, interact and complete transactions.

Build the product as a coherent ecosystem, not a set of disconnected feature demos.

---

**Document generated from the KWETU App Master Product Requirements Document.**
**Date: November 1, 2026**
