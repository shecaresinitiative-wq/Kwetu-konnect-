# KWETU: Developer Handover

**Read this first.** It tells you what exists, what the rules are, what Block 2 is, and how to hand the work back so the lead developer can continue with Block 3 without anything breaking.

Handover written at the end of **Block 1** (9 Nov 2026). Block 1 was built by the lead developer (Claude). You are building **Block 2**.

---

## 1. What KWETU is (60 seconds)

A mobile-first local platform ("Your city, your people, your plans.") that joins people, service providers, venues, event organisers and transport operators in one town. One login, one feed, one booking and payment layer. Launch market: Bungoma, Kenya, but nothing is hardcoded to one town. Full spec: [`PRD.md`](PRD.md). The product is built in **blocks**; each block ends with a working, tested zip.

## 2. The roadmap: 10 blocks in total

| # | Block | Delivers (acceptance tests are in PRD section 17) |
|---|---|---|
| 1 | **Foundation** (done) | Splash, landing, shell, auth, profile, towns, DB foundation + RLS |
| 2 | **Events and ticketing** | Organiser, event publishing, ticket types, sandbox payment, QR tickets, gate scanning, organiser dashboard (Tests C, D) |
| 3 | **Businesses and experiences** | Business pages, recurring activities (Wednesday karaoke), interest, RSVP, reach vs attendance (Test E) |
| 4 | **Social feed** | Posts, images, likes, comments, follows, saves, reports; feed ranking |
| 5 | **Service providers and booking engine** | Provider profiles, availability, bookings, no double-booking, queues; wellness is the first category (Test B, plus Test A without companionship) |
| 6 | **Transport** | Driver profile, online/offline, request-and-accept rides, trips (Test F) |
| 7 | **Messaging, reviews, notification centre** | Chat with references, verified reviews, real notifications and preferences |
| 8 | **Admin and moderation** | Dashboard, verification workflow, reports, disputes, analytics (Test G) |
| 9 | **Real payments** | M-Pesa (Daraja) behind the payment provider interface, settlements, refunds |
| 10 | **Companionship and same-venue discovery** | Only after legal advice (see section 8) |

Block 1 is complete. 9 remain. Order can change; ask the owner before reordering.

## 3. Current state (end of Block 1)

### Built and tested
- Splash screen, landing page, app shell (header, town selector, 5-tab nav, Create menu), registration (18+, Kenyan phone), login, logout, profile edit, Home, Explore, Activity (empty state), legal drafts.
- Database: `towns`, `neighbourhoods`, `profiles`, `profile_private`, `user_roles`, `audit_logs`, with Row Level Security and a server-side 18+ gate. Migrations `0001` and `0002` plus `seed.sql` (8 towns, Bungoma default).
- Demo mode (no backend; data in the browser) and Supabase mode (real). Chosen by `js/config.js`.
- Tests: database/RLS, JS unit, Supabase adapter (fake client), site integrity, real-browser end to end.

### Not built (full list in `../CHECKLIST.md`)
Phone/email verification, image upload, posts/feed, events, bookings, transport, messaging, reviews, payments, admin. The Create menu shows "Soon" for these. The two sample cards on Home are labelled SAMPLE.

### Known gaps and honest unknowns
1. **The live browser-to-Supabase network call has never been run.** The lead developer's sandbox cannot reach supabase.co. The database rules were verified on the real project via SQL, and the adapter was tested against a fake client. **Your Step 0 is one real sign-up** (section 5).
2. Demo-mode passwords use a weak non-cryptographic hash. Demo only.
3. supabase-js is loaded from a CDN at `@2` (unpinned). Pin an exact version before production.
4. Town coordinates are approximate. No neighbourhoods are seeded (no invented data).
5. The owner must turn **Confirm email** off in Supabase Auth while testing.

## 4. Environment

| Item | Value |
|---|---|
| Supabase project | `KWETU`, ref `oujucwnvfpgndylucgjh`, region eu-central-1 (Frankfurt) |
| API URL | `https://oujucwnvfpgndylucgjh.supabase.co` |
| Public key | `sb_publishable_h59__hk15vxD6GcBxeStwQ_YfXRde2i` (publishable; safe in the repo) |
| Applied to that project | Migration 0001 (as `foundation`), migration 0002 (as `lock_down_function_execute`), the 8-town seed |
| Hosting | Render **Static Site**, deployed from GitHub; no build step |
| Secrets | **None are in the repo.** Never commit a `service_role` key or any provider secret |

**Getting access.** Ask the owner to invite you to the Supabase organisation, or create your own dev project by following the README. If you use your own, you must **restore the values above in `js/config.js` before returning the zip.**

**Migration history gotcha.** The lead applied migrations through the Supabase API, so the project's recorded migration versions are timestamps from apply time, not the file names. If you use the Supabase CLI (`db push`) it will try to re-run 0001 and 0002 and fail. Either apply new migrations in the SQL Editor, or run `supabase migration repair` first. Never re-run 0001 or 0002 on this project.

**Tooling to run the tests**
- Node 18+ (`node tests/js/*.test.js`).
- Python 3 with `playwright` and a Chrome/Chromium binary (`python3 tests/browser/smoke.py`; set `CHROME=/path` if needed).
- A local PostgreSQL 16 (`tests/run_db_tests.sh`; needs `PGHOST` and a superuser `PGUSER`; it creates and drops a database called `kwetu_test`).

## 5. Step 0, before you write anything

1. Unzip, open `index.html`, confirm it loads with no DEMO chip.
2. Do **one real sign-up** with a fresh email (Confirm email must be off), then log in, edit the profile, and log out.
3. In the Supabase dashboard check that the user appears in Authentication, with a matching row in `profiles`, `profile_private` and `user_roles`.
4. Run all four test commands and confirm they pass. Report the results of steps 2 to 4 in your Block 2 report. If sign-up fails, fix that first and tell the lead exactly what the error was.

## 6. The rules (do not break these)

These exist so that Block 3 can be built on your work. Breaking them is what makes a codebase "crumble".

### Structure
1. **Add, never reshape.** Do not rename or move existing files or folders. Do not restructure working code. Change existing code only where your feature needs it, and keep the change minimal.
2. **No build step, no framework.** Plain HTML, CSS and classic JavaScript on the shared `KWETU` namespace (no ES modules, no npm requirement to run the site). It must still run by double-clicking `index.html` and on Render as a static site. Third-party browser libraries are allowed only if vendored into `js/vendor/` with their licence file, and listed in `ARCHITECTURE.md`.
3. **One zip, same name.** Deliver the whole project as `kwetu.zip` with a single top-level folder `kwetu/`. If you delete a file, list it in your report (the owner's upload does not remove old files automatically).

### Code
4. **Pages:** one HTML file plus one `js/pages/<name>.js` that sets `KWETU.pages.<name> = { init }`. Copy a sibling page. Pages never call Supabase or localStorage directly.
5. **Data layer:** every data call is a method in `js/data.js`, implemented in **both** adapters (demo and Supabase) and exposed on the `KWETU.data` facade. All methods return Promises. The demo adapter must keep the whole app usable with no backend, because the browser tests run in demo mode.
6. **Styling:** use the tokens in `css/tokens.css`. No hardcoded colours, no new fonts. Mobile first, then tablet and desktop. Keep the navy, purple and turquoise look; avoid clutter.
7. **Safety in the browser:** escape all user text with `KWETU.esc` before putting it in HTML. Redirects only through `KWETU.safeNext`. Validate every form field and show inline errors with `KWETU.fieldError`.
8. **Honesty in the UI:** never show something as available, paid, verified or successful unless it is. Anything simulated is labelled (SAMPLE, SANDBOX, DEMO). Empty states say plainly that nothing is there yet.

### Database and security
9. **New migration files only.** Name them `supabase/migrations/<YYYYMMDDHHMMSS>_<what>.sql`, later than the last one. **Never edit a migration that has been applied.** 0001 and 0002 are applied.
10. **Every new table** has, in the same migration: RLS enabled, explicit policies, foreign keys, indexes, `created_at`/`updated_at` (use `set_updated_at()`), and tests in `tests/db/`. Default is deny; anonymous access only where the data is genuinely public.
11. **Every `security definer` function** has `EXECUTE` revoked from `public, anon, authenticated` in the same migration unless an RLS policy must evaluate it (as `is_admin()` does). Supabase exposes every public function as an API endpoint.
12. **Sensitive operations never run in the browser:** payment confirmation, ticket issue, ticket validation, commission calculation, role grants. Pattern: business rules live in SQL functions callable only by `service_role` (atomic, testable locally), and a Supabase Edge Function authenticates the caller and invokes them. Secrets go in Supabase function secrets.
13. **Clients cannot write their own privileges.** No client policy may let a user grant themselves a role, verification, status or money.
14. **Verify migrations twice:** (a) `tests/run_db_tests.sh` locally, (b) on the real Supabase project, then run the Supabase **security advisor** and explain any new warning in your report.

### Product rules (from the PRD, non-negotiable)
15. Adults only (18+). Never expose a private address or continuous location. Location sharing is opt-in and temporary.
16. A payment is never shown as successful until the provider confirms it. Simulated payments are labelled SANDBOX and never described as real.
17. Reviews only for completed, verified interactions. Basic social use and basic event publishing stay free.
18. Prices are whole Kenyan shillings (integer KSh). Times are stored as UTC (`timestamptz`) and shown in Africa/Nairobi.

### Quality gate (must all pass before you return the zip)
```
node tests/js/core.test.js
node tests/js/supabase-adapter.test.js
node tests/js/site.test.js
python3 tests/browser/smoke.py
PGHOST=... PGUSER=... ./tests/run_db_tests.sh
```
Add tests for your own work in the same places. Update `../CHECKLIST.md` and `BLOCKS.md` (section 9 below). Do not tick a box unless it works and is tested.

## 7. Block 2 brief: Events and Ticketing

**Goal:** PRD Tests C and D pass end to end. An organiser publishes an event with ticket types; a customer discovers it, buys a ticket (sandbox payment) and receives a unique QR ticket; gate staff scan it, it is marked used, and a second scan is rejected as a duplicate.

### Must have
1. **Organiser capability.** A signed-in adult can activate "Event organiser" from Profile. The role is created `active` through a backend function (never a client write). Organisers carry a `verified` flag that is **false** until the admin block exists; the owner may flip it by SQL. Unverified organisers show an "Unverified organiser" badge on their events. Never let an unofficial account appear as the official organiser.
2. **Tables** (new migration, with RLS and tests): `event_categories` (seeded), `events`, `event_ticket_types`, `tickets`, `ticket_scans`, `event_staff` (organiser-appointed gate staff), `transactions`, `payment_records`. Suggested fields:
   - `events`: organiser_id, title, description, category_id, town_id, neighbourhood_id (optional), venue_name, venue_address (public venue only, never a home address), starts_at, ends_at, poster_url, contact_phone/email (optional), status (`draft`, `published`, `paused`, `cancelled`, `completed`), timestamps.
   - `event_ticket_types`: event_id, name, kind (`free`, `early_bird`, `regular`, `vip`, `other`), price_kes (integer >= 0), quantity (> 0), max_per_order, sales_start, sales_end.
   - `tickets`: event_id, ticket_type_id, owner_id, transaction_id, code (random, unguessable, unique, at least 128 bits), status (`valid`, `used`, `cancelled`, `refunded`), issued_at, used_at.
   - `ticket_scans`: ticket_id (nullable if code unknown), event_id, scanned_by, result (`accepted`, `duplicate`, `invalid`, `wrong_event`), scanned_at.
   - `transactions` / `payment_records`: user, amount_kes, status (`pending`, `succeeded`, `failed`, `refunded`), provider (`sandbox`), provider_ref, raw provider payload. Money rows are written only by the backend.
3. **Atomic rules in SQL functions** (service_role only): `issue_tickets(transaction_id)` locks the ticket type row, enforces remaining quantity, sales window, max per order and published status, and cannot oversell under concurrent purchases. `validate_ticket(code, event_id, staff_id)` flips `valid` to `used` in a single conditional update, so two simultaneous scans cannot both be accepted, and logs every scan.
4. **Edge Functions** (Deno/TypeScript, in `supabase/functions/<name>/`): `purchase-ticket` (creates the transaction, runs the **sandbox** provider, on success calls `issue_tickets`) and `validate-ticket` (checks the caller is the organiser or appointed staff for that event, then calls `validate_ticket`). Put the provider behind an interface (`sandbox` now, `mpesa` in Block 9) so adding M-Pesa later changes nothing else. No credentials in code.
5. **Pages** (follow the page pattern): create/edit event (with validation), event detail, my tickets (QR shown), organiser dashboard, gate scanner. Enable the Create menu "Event" item. Replace the SAMPLE event cards on Home and the empty state under Explore > Events with real published events for the selected town.
6. **QR.** Generate the QR in the browser with a vendored MIT-licensed library. The QR carries only the ticket code; **validity is decided by the server**, never by the QR contents or the browser. Scanner uses the camera via the BarcodeDetector API where available, a vendored fallback decoder, and always a **manual code entry** fallback.
7. **Organiser dashboard.** Tickets issued, sold, revenue, remaining inventory, free registrations, check-ins, sales by ticket type. Views, interest, purchases and actual attendance must be **separate numbers**; where a metric is not tracked yet (views, shares, interest arrive with later blocks) show "Not tracked yet", never zero.
8. **Poster upload** through Supabase Storage (public-read bucket for event media, write only by the event's organiser). In demo mode, keep the image as a local data URL.
9. **Demo adapter parity.** The full flow (publish, buy, QR, scan, duplicate rejection) must work in demo mode, clearly labelled, so the browser tests cover Tests C and D.
10. **Sandbox honesty.** The payment step displays "SANDBOX: no real money moves". Receipts say the same.

### Should have (if time allows; otherwise list as incomplete)
- Edit, pause and cancel an event, with a visible cancellation notice on the event page.
- Free and multiple ticket types per event; early-bird windows.
- Report an event (impersonation, fake event, fraud) as a row in a `reports` table.
- Design the offline scanner: define the secure downloadable ticket list and reconcile model in `ARCHITECTURE.md` even if the UI is Block 2b.

### Out of scope for Block 2
Real M-Pesa, refunds and settlement (Block 9); notifications centre (Block 7); social sharing and interest counts (Blocks 3 and 4); admin verification UI (Block 8); paid promotion; commission beyond a single configurable value stored with each transaction.

### Acceptance (all must pass; automate what you can)
- **Test C:** organiser registers, activates the role, creates an event with a poster and two ticket types, publishes; a different customer finds it under their town, buys one ticket, and sees a unique QR in "My tickets".
- **Test D:** a gate operator scans the code and gets `accepted` with the ticket category; scanning the same code again returns `duplicate`; an unknown code returns `invalid`; a code for another event returns `wrong_event`.
- **Security (DB tests):** a customer cannot read another person's tickets, transactions or any scan log; a customer cannot call `issue_tickets` or `validate_ticket`; only the organiser or appointed staff can scan; a non-organiser cannot publish; buying more than the remaining quantity fails; two simultaneous buyers of the last ticket produce exactly one ticket.
- The four-command quality gate (section 6) passes, including new tests.
- Security advisor run on the real project, new warnings explained.

## 8. Needs outside decisions (do not guess; flag to the owner)
- **Companionship (Block 10) needs a Kenyan lawyer first.** Do not build it or add companion roles/fields.
- Terms, privacy, guidelines are drafts. Payments must go through a licensed provider; the platform does not hold customer funds. Ticket commission and tax treatment need advice.
- Who verifies organisers, drivers and providers, and how, is undecided.

## 9. How to hand back (the return protocol)

Return **`kwetu.zip`** (whole project, folder `kwetu/`) and append this report to `docs/BLOCKS.md`. The lead developer will not continue from a zip that lacks the report.

```
## Block 2: Events and Ticketing (<date>, <developer>)

**Step 0 result:** real sign-up worked / failed (exact error).
**Built:** (bullets, in plain words)
**Files added / changed / deleted:** (lists; deletions matter)
**Migrations:** file names; applied to which Supabase project, when, and how (SQL Editor / CLI).
**Edge Functions:** names, deployed to which project, secrets they need (names only, never values).
**Vendored libraries:** name, version, licence, where used.
**Deviations from the brief:** what, and why.
**Not finished / known issues:**
**Tests:** paste the pass lines of all four commands + DB tests.
**Security advisor:** new warnings and how each was handled.
**Decisions needed from the owner:**
```

Also update `CHECKLIST.md` (tick only what is tested), and `ARCHITECTURE.md` if you introduced any convention (for example the Edge Function layout or the provider interface).

## 10. Quick map of the code

```
index.html            splash + landing         login/register.html   auth
home/explore/activity/profile.html   the 5-tab app      terms/privacy/guidelines.html   drafts
css/tokens.css        design tokens (change colours here only)
js/config.js          public settings; empty keys = demo mode
js/core.js            helpers: KWETU.validate (phone, age, password), esc, safeNext, fieldError, icon, toast, sheet, wordmark
js/data.js            THE data layer: demo adapter + Supabase adapter + facade
js/shell.js           page boot, auth guard (data-requires-auth), header, town selector, nav, Create menu
js/categories.js      the pillars as categories
js/pages/*.js         one module per page
supabase/migrations/  numbered SQL (0001, 0002 applied)      supabase/seed.sql   towns
tests/db  tests/js  tests/browser     the quality gate
docs/PRD.md  ARCHITECTURE.md  BLOCKS.md  HANDOVER.md         ../CHECKLIST.md  ../README.md
```

Adding a page: HTML file (copy a sibling) + `js/pages/<name>.js` + nav link if needed. Adding data: both adapters in `data.js`. Adding a pillar category: one entry in `categories.js`.
