# Build log

One entry per block. The checklist (`../CHECKLIST.md`) holds the live feature status.

## Block 1: Foundation (9 Nov 2026)

Splash and landing, design system, app shell with five-tab navigation, registration / login / profile, Home / Explore / Activity, multi-town support (Bungoma default), legal drafts, database foundation with Row Level Security, demo mode, four test suites.

**Decisions made**
- Plain HTML/CSS/JS, no build step, so the project can be opened, edited and extended directly.
- Registration is 18+ for the whole platform (also enforced in the database).
- Phone is required at sign-up (M-Pesa-first market); verification comes later.
- The "users" table in the PRD is Supabase `auth.users`; `profiles` extends it, and private fields are split into `profile_private`.
- Neighbourhoods are not seeded; no invented data. Admins add them.

**Supabase connected (same day)**
- Project created in Frankfurt (no African region exists); migrations 0001 and 0002 plus the seed applied; keys placed in `js/config.js`.
- 0002 was added after the Supabase security advisor flagged that trigger helpers were callable through the public API. Lesson recorded in `docs/ARCHITECTURE.md`: every new `security definer` function gets its `EXECUTE` revoked in the same migration.

## Next blocks (proposed order, change freely)

The full 10-block roadmap and the Block 2 brief are in `HANDOVER.md`. In short: 2 Events and ticketing, 3 Businesses and experiences, 4 Social feed, 5 Service providers and booking engine, 6 Transport, 7 Messaging, reviews and notifications, 8 Admin and moderation, 9 Real payments (M-Pesa), 10 Companionship (only after legal advice; see the checklist).
