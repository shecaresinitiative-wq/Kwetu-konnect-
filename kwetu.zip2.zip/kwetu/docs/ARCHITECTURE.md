# KWETU Architecture

## Principle: boring, stable, extendable

Static site (HTML + CSS + classic JS) on a Supabase backend. No build step, no framework lock-in, no files that need to be taken apart to add a feature. If the product later outgrows this, the data layer and the SQL migrations carry over unchanged to a framework front end or a Flutter app.

## Layers

```
HTML page  ->  js/pages/<page>.js  ->  KWETU.data (js/data.js)  ->  demo adapter (localStorage)
                                                                  ->  supabase adapter (Auth + Postgres + RLS)
                                          sensitive work        ->  Supabase Edge Functions (service role)
```

- **Pages** only render and handle events. They never call Supabase or localStorage.
- **`KWETU.data`** is the single seam. Every method exists in both adapters and always returns a Promise. This is why the whole app is testable with no backend and switches to Supabase by filling two values in `js/config.js`.
- **Shell** (`js/shell.js`) boots every page: session, towns, auth guard, header, nav.

## Security model

- Row Level Security is on for every table. Default is deny; policies open the minimum.
- **Private data** (phone, date of birth) lives in `profile_private`, readable only by its owner and admins.
- **Clients cannot** insert or change roles, change their own status, change date of birth or phone verification, or touch the audit log. Those paths exist only for the backend (service role) or admins.
- **Backend only (Edge Functions):** payment confirmation, ticket issue and validation, commission calculation, role verification and grants. The browser is never trusted for these.
- **Age gate** is enforced in the database (`handle_new_user`), not just the form.
- **Secrets:** `js/config.js` holds only the public URL and anon key. Everything private lives in Edge Function secrets.
- **Output safety:** user text is escaped before rendering (`KWETU.esc`); redirects are restricted to local pages (`KWETU.safeNext`).

## Conventions for new blocks

| You are adding | Do this |
|---|---|
| A table | New migration file, RLS enabled in the same file, policies, indexes, `updated_at` trigger, tests in `tests/db/` |
| A page | HTML file + `js/pages/<name>.js` registering `KWETU.pages.<name>` |
| A data call | Add to both adapters in `js/data.js`, then to the `KWETU.data` facade |
| A pillar category | One entry in `js/categories.js` |
| A `security definer` function | Revoke `EXECUTE` from `public, anon, authenticated` in the same migration (Supabase exposes every public function as an API endpoint). Keep it callable only if an RLS policy must evaluate it, as with `is_admin()` |
| A secret-touching action | An Edge Function in `supabase/functions/<name>/`, called from `data.js` |
| A payment provider | Implement the provider interface behind a `payments` module; keep sandbox mode labelled |

## Known limits of Block 1

- Demo-mode passwords use a weak non-cryptographic hash. It is for trying the UI, never for real data.
- The Supabase library is loaded from a CDN (`@2`). Pin an exact version before production.
- Town coordinates are approximate.
