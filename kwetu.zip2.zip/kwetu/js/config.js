/*
 * KWETU runtime configuration.
 *
 * Only PUBLIC values belong here. This file is committed to GitHub and served to browsers.
 * NEVER put a Supabase service_role key, an M-Pesa secret, or any private credential in this file.
 * Private credentials live in Supabase Edge Function secrets (see docs/ARCHITECTURE.md).
 *
 * Leave supabaseUrl / supabaseAnonKey empty to run in DEMO MODE (data stays in this browser only).
 * Fill both in to switch the whole app to your real Supabase project.
 */
window.KWETU_CONFIG = {
  appName: 'KWETU',
  tagline: 'Your city, your people, your plans.',

  // Supabase > Project Settings > API
  supabaseUrl: 'https://oujucwnvfpgndylucgjh.supabase.co',
  supabaseAnonKey: 'sb_publishable_h59__hk15vxD6GcBxeStwQ_YfXRde2i',    // publishable key. Safe to expose because Row Level Security protects the data.

  // The launch market. Everything reads this value; no page hardcodes a town.
  defaultTownSlug: 'bungoma',

  currency: { code: 'KES', label: 'KSh' },
  phoneCountryCode: '+254',
  minAge: 18,

  // 'sandbox' = simulated payments, clearly labelled. Real M-Pesa arrives in a later block.
  paymentMode: 'sandbox'
};
