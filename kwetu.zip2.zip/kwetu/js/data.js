/*
 * KWETU data layer.
 *
 * Every page talks to `KWETU.data`, never to Supabase or localStorage directly.
 * Two interchangeable adapters sit behind it:
 *   - demo     : stores everything in this browser (used when js/config.js has no Supabase keys)
 *   - supabase : real auth and Postgres with Row Level Security
 * New blocks add methods here (listEvents, createBooking, ...) to BOTH adapters, nothing else changes.
 */
(function (global) {
  'use strict';
  var K = global.KWETU;

  /* Public launch-market data. Mirrors supabase/seed.sql. Coordinates are approximate. */
  var STATIC_TOWNS = [
    { slug: 'bungoma', name: 'Bungoma', county: 'Bungoma', lat: 0.5635, lng: 34.5606 },
    { slug: 'webuye', name: 'Webuye', county: 'Bungoma', lat: 0.6074, lng: 34.7712 },
    { slug: 'kakamega', name: 'Kakamega', county: 'Kakamega', lat: 0.2827, lng: 34.7519 },
    { slug: 'kitale', name: 'Kitale', county: 'Trans Nzoia', lat: 1.0157, lng: 35.0062 },
    { slug: 'eldoret', name: 'Eldoret', county: 'Uasin Gishu', lat: 0.5143, lng: 35.2698 },
    { slug: 'kisumu', name: 'Kisumu', county: 'Kisumu', lat: -0.0917, lng: 34.768 },
    { slug: 'nairobi', name: 'Nairobi', county: 'Nairobi', lat: -1.2921, lng: 36.8219 },
    { slug: 'mombasa', name: 'Mombasa', county: 'Mombasa', lat: -4.0435, lng: 39.6682 }
  ];

  function fail(message) { throw new Error(message); }

  /* =====================================================================
   * DEMO ADAPTER (browser-only; NOT secure; never use a real password)
   * ===================================================================== */
  var USERS_KEY = 'kwetu.demo.users';
  var SESSION_KEY = 'kwetu.demo.session';

  // Weak, non-cryptographic hash. Demo mode only.
  function demoHash(str) {
    var h1 = 5381, h2 = 52711;
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      h1 = ((h1 << 5) + h1 + c) | 0;
      h2 = ((h2 << 5) ^ h2 ^ c) | 0;
    }
    return (h1 >>> 0).toString(16) + (h2 >>> 0).toString(16);
  }
  function demoId() { return 'demo-' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }
  function demoUsers() { return K.store.get(USERS_KEY, []); }
  function townByslug(slug) { return STATIC_TOWNS.filter(function (t) { return t.slug === slug; })[0] || null; }

  function toProfile(u) {
    var town = townByslug(u.townSlug);
    return {
      id: u.id, email: u.email, displayName: u.displayName, bio: u.bio || '',
      townSlug: u.townSlug, townName: town ? town.name : '',
      phone: u.phone, dob: u.dob, roles: u.roles, createdAt: u.createdAt, demo: true
    };
  }

  var demo = {
    init: function () { return Promise.resolve(); },
    listTowns: function () { return Promise.resolve(STATIC_TOWNS.slice()); },

    getSession: function () {
      var s = K.store.get(SESSION_KEY, null);
      if (!s) return Promise.resolve(null);
      var u = demoUsers().filter(function (x) { return x.id === s.userId; })[0];
      return Promise.resolve(u ? { user: { id: u.id, email: u.email } } : null);
    },

    signUp: function (f) {
      var users = demoUsers();
      var email = f.email.trim().toLowerCase();
      if (users.some(function (u) { return u.email === email; })) fail('An account with this email already exists. Try logging in.');
      if (users.some(function (u) { return u.phone === f.phone; })) fail('An account with this phone number already exists.');
      var age = K.validate.age(f.dob);
      if (age === null || age < K.config.minAge) fail('You must be ' + K.config.minAge + ' or older to use KWETU.');
      var salt = Math.random().toString(36).slice(2);
      var user = {
        id: demoId(), email: email, salt: salt, passHash: demoHash(salt + f.password),
        displayName: f.displayName.trim(), bio: '', phone: f.phone, dob: f.dob,
        townSlug: f.townSlug, roles: [{ role: 'user', status: 'active' }], createdAt: new Date().toISOString()
      };
      users.push(user);
      K.store.set(USERS_KEY, users);
      K.store.set(SESSION_KEY, { userId: user.id });
      return Promise.resolve({ user: { id: user.id, email: user.email }, needsConfirmation: false });
    },

    signIn: function (f) {
      var email = f.email.trim().toLowerCase();
      var u = demoUsers().filter(function (x) { return x.email === email; })[0];
      if (!u || u.passHash !== demoHash(u.salt + f.password)) fail('Incorrect email or password.');
      K.store.set(SESSION_KEY, { userId: u.id });
      return Promise.resolve({ user: { id: u.id, email: u.email } });
    },

    signOut: function () { K.store.remove(SESSION_KEY); return Promise.resolve(); },

    getProfile: function () {
      var s = K.store.get(SESSION_KEY, null);
      var u = s && demoUsers().filter(function (x) { return x.id === s.userId; })[0];
      return Promise.resolve(u ? toProfile(u) : null);
    },

    updateProfile: function (f) {
      var s = K.store.get(SESSION_KEY, null);
      var users = demoUsers();
      var u = s && users.filter(function (x) { return x.id === s.userId; })[0];
      if (!u) fail('You are not logged in.');
      if (!townByslug(f.townSlug)) fail('Please choose a valid town.');
      u.displayName = f.displayName.trim();
      u.bio = (f.bio || '').trim();
      u.townSlug = f.townSlug;
      K.store.set(USERS_KEY, users);
      return Promise.resolve(toProfile(u));
    }
  };

  /* =====================================================================
   * SUPABASE ADAPTER
   * ===================================================================== */
  var sb = null;
  var SUPABASE_CDN = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js';

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = src; s.onload = resolve;
      s.onerror = function () { reject(new Error('Could not load the Supabase library. Check your internet connection.')); };
      document.head.appendChild(s);
    });
  }
  function friendly(error) {
    var m = (error && error.message) || 'Something went wrong. Please try again.';
    if (/invalid login/i.test(m)) return 'Incorrect email or password.';
    if (/already registered|already been registered/i.test(m)) return 'An account with this email already exists. Try logging in.';
    if (/database error saving new user/i.test(m)) return 'We could not create your account. Check that you are ' + K.config.minAge + ' or older and that your phone number is not already in use.';
    if (/email not confirmed/i.test(m)) return 'Please confirm your email first. Check your inbox for the link.';
    return m;
  }

  var remote = {
    init: function () {
      if (sb) return Promise.resolve();
      var ready = global.supabase ? Promise.resolve() : loadScript(SUPABASE_CDN);
      return ready.then(function () {
        sb = global.supabase.createClient(K.config.supabaseUrl, K.config.supabaseAnonKey);
      });
    },

    listTowns: function () {
      return sb.from('towns').select('slug,name,county,latitude,longitude').eq('is_active', true).order('name')
        .then(function (r) {
          if (r.error || !r.data || !r.data.length) return STATIC_TOWNS.slice();
          return r.data.map(function (t) { return { slug: t.slug, name: t.name, county: t.county, lat: t.latitude, lng: t.longitude }; });
        });
    },

    getSession: function () {
      return sb.auth.getSession().then(function (r) {
        var s = r.data && r.data.session;
        return s ? { user: { id: s.user.id, email: s.user.email } } : null;
      });
    },

    signUp: function (f) {
      return sb.auth.signUp({
        email: f.email.trim(), password: f.password,
        options: { data: { display_name: f.displayName.trim(), phone: f.phone, date_of_birth: f.dob, town_slug: f.townSlug } }
      }).then(function (r) {
        if (r.error) fail(friendly(r.error));
        return { user: r.data.user, needsConfirmation: !r.data.session };
      });
    },

    signIn: function (f) {
      return sb.auth.signInWithPassword({ email: f.email.trim(), password: f.password }).then(function (r) {
        if (r.error) fail(friendly(r.error));
        return { user: r.data.user };
      });
    },

    signOut: function () { return sb.auth.signOut().then(function () { return undefined; }); },

    getProfile: function () {
      return sb.auth.getUser().then(function (u) {
        var user = u.data && u.data.user;
        if (!user) return null;
        return Promise.all([
          sb.from('profiles').select('id,display_name,bio,created_at,towns(slug,name)').eq('id', user.id).single(),
          sb.from('profile_private').select('phone_e164,date_of_birth').eq('user_id', user.id).maybeSingle(),
          sb.from('user_roles').select('role,status').eq('user_id', user.id)
        ]).then(function (res) {
          var p = res[0].data, priv = res[1].data || {}, roles = res[2].data || [];
          if (res[0].error || !p) fail('Could not load your profile.');
          return {
            id: user.id, email: user.email, displayName: p.display_name, bio: p.bio || '',
            townSlug: p.towns ? p.towns.slug : '', townName: p.towns ? p.towns.name : '',
            phone: priv.phone_e164 || '', dob: priv.date_of_birth || '', roles: roles, createdAt: p.created_at, demo: false
          };
        });
      });
    },

    updateProfile: function (f) {
      return sb.auth.getUser().then(function (u) {
        var user = u.data && u.data.user;
        if (!user) fail('You are not logged in.');
        return sb.from('towns').select('id').eq('slug', f.townSlug).single().then(function (t) {
          if (t.error || !t.data) fail('Please choose a valid town.');
          return sb.from('profiles').update({ display_name: f.displayName.trim(), bio: (f.bio || '').trim() || null, town_id: t.data.id }).eq('id', user.id);
        }).then(function (r) {
          if (r.error) fail(friendly(r.error));
          return remote.getProfile();
        });
      });
    }
  };

  /* Public facade: picks the adapter once config is known. */
  function adapter() { return K.isDemo() ? demo : remote; }
  // Every call returns a Promise, even if an adapter throws synchronously, so callers can always use .catch().
  function call(name, arg) {
    try { return Promise.resolve(adapter()[name](arg)); } catch (e) { return Promise.reject(e); }
  }
  K.data = {
    init: function () { return call('init'); },
    listTowns: function () { return call('listTowns'); },
    getSession: function () { return call('getSession'); },
    signUp: function (f) { return call('signUp', f); },
    signIn: function (f) { return call('signIn', f); },
    signOut: function () { return call('signOut'); },
    getProfile: function () { return call('getProfile'); },
    updateProfile: function (f) { return call('updateProfile', f); },
    staticTowns: STATIC_TOWNS
  };
})(typeof window !== 'undefined' ? window : globalThis);
