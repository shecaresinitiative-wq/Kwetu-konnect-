/*
 * KWETU core: namespace, helpers, validation, icons, toasts and sheets.
 * Classic scripts on a shared `KWETU` namespace, so the site works by double-clicking
 * a file or from any static host. No build step needed.
 */
(function (global) {
  'use strict';
  var K = (global.KWETU = global.KWETU || {});
  K.config = global.KWETU_CONFIG || {};
  K.pages = K.pages || {};

  /** True when Supabase is not configured: the app runs on this device only. */
  K.isDemo = function () { return !(K.config.supabaseUrl && K.config.supabaseAnonKey); };

  /* ---------- DOM helpers ---------- */
  K.$ = function (sel, root) { return (root || document).querySelector(sel); };
  K.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  K.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  /* ---------- Safe storage (localStorage can be blocked) ---------- */
  K.store = {
    get: function (key, fallback) {
      try { var v = global.localStorage.getItem(key); return v == null ? fallback : JSON.parse(v); }
      catch (e) { return fallback; }
    },
    set: function (key, value) {
      try { global.localStorage.setItem(key, JSON.stringify(value)); return true; }
      catch (e) { return false; }
    },
    remove: function (key) { try { global.localStorage.removeItem(key); } catch (e) { /* ignore */ } }
  };

  /* ---------- Validation ---------- */
  K.validate = {
    email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v || '').trim()); },

    /** Accepts 07xx, 01xx, 7xx, 1xx, 2547xx, +2547xx (spaces and dashes allowed). Returns +254XXXXXXXXX or null. */
    phone: function (raw) {
      var s = String(raw || '').replace(/[\s\-().]/g, '');
      if (s.charAt(0) === '+') s = s.slice(1);
      if (/^254[17]\d{8}$/.test(s)) return '+' + s;
      if (/^0[17]\d{8}$/.test(s)) return '+254' + s.slice(1);
      if (/^[17]\d{8}$/.test(s)) return '+254' + s;
      return null;
    },

    /** Age in whole years from YYYY-MM-DD, or null if the date is invalid. */
    age: function (dob, now) {
      var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dob || '');
      if (!m) return null;
      var y = +m[1], mo = +m[2], d = +m[3];
      var dt = new Date(Date.UTC(y, mo - 1, d));
      if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return null;
      now = now || new Date();
      var age = now.getUTCFullYear() - y;
      if (now.getUTCMonth() + 1 < mo || (now.getUTCMonth() + 1 === mo && now.getUTCDate() < d)) age--;
      return age;
    },

    password: function (v) { return typeof v === 'string' && v.length >= 8 && /[A-Za-z]/.test(v) && /\d/.test(v); },
    displayName: function (v) { var s = String(v || '').trim(); return s.length >= 2 && s.length <= 60; }
  };

  /** Only allow redirects to other KWETU pages in this folder (blocks open redirects). */
  K.safeNext = function (next, fallback) {
    return /^[a-z0-9-]+\.html(\?[^#\s]*)?$/i.test(next || '') ? next : (fallback || 'home.html');
  };

  /* ---------- Inline form errors ---------- */
  K.fieldError = function (input, message) {
    var field = input.closest('.field') || input.parentNode;
    var err = field.querySelector('.field-error');
    if (message) {
      input.setAttribute('aria-invalid', 'true');
      if (!err) { err = document.createElement('p'); err.className = 'field-error'; err.setAttribute('role', 'alert'); field.appendChild(err); }
      err.textContent = message;
    } else {
      input.removeAttribute('aria-invalid');
      if (err) err.remove();
    }
  };

  /* ---------- Icons (24px, stroke) ---------- */
  var ICONS = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    bell: '<path d="M6 9a6 6 0 0112 0c0 6 2 7 2 7H4s2-1 2-7"/><path d="M10 20a2 2 0 004 0"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c3 0 5 1.5 5 4.5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    pin: '<path d="M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    ticket: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M14 6v12" stroke-dasharray="2 2"/>',
    spa: '<path d="M5 19c0-8 5-14 15-14 0 10-6 15-15 14z"/><path d="M5 19c3-5 6-8 10-10"/>',
    car: '<path d="M5 16l1.5-5a2 2 0 012-1.5h7a2 2 0 012 1.5L19 16"/><rect x="3" y="16" width="18" height="4" rx="1.5"/>',
    music: '<path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2.5"/><circle cx="17" cy="16" r="2.5"/>',
    store: '<path d="M4 9l1.5-5h13L20 9"/><path d="M4 9a2.7 2.7 0 005.3 0 2.7 2.7 0 005.4 0A2.7 2.7 0 0020 9"/><path d="M5 12v8h14v-8"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    chevron: '<path d="M9 6l6 6-6 6"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    logout: '<path d="M9 4H5v16h4"/><path d="M16 8l4 4-4 4M20 12H9"/>',
    doc: '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M10 12h5M10 16h5"/>'
  };
  K.icon = function (name, size) {
    size = size || 24;
    return '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  };

  /** The KWETU wordmark, with the E drawn as three bars. Colour comes from the parent via currentColor. */
  K.wordmark = function (extraClass) {
    return '<span class="wm ' + (extraClass || '') + '" role="img" aria-label="KWETU">K<span aria-hidden="true">W</span><span class="e" aria-hidden="true"><i></i><i></i><i></i></span><span aria-hidden="true">T</span><span aria-hidden="true">U</span></span>';
  };

  /* ---------- Toasts ---------- */
  K.toast = function (message, type) {
    var wrap = K.$('.toast-wrap');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; wrap.setAttribute('aria-live', 'polite'); document.body.appendChild(wrap); }
    var t = document.createElement('div');
    t.className = 'toast' + (type === 'error' ? ' error' : '');
    t.textContent = message;
    wrap.appendChild(t);
    setTimeout(function () { t.remove(); }, 3600);
  };

  /* ---------- Bottom sheet ---------- */
  /** K.sheet({ title, html, onMount(el, close) }) -> close() */
  K.sheet = function (opts) {
    var back = document.createElement('div');
    back.className = 'sheet-backdrop';
    back.innerHTML = '<div class="sheet" role="dialog" aria-modal="true" aria-label="' + K.esc(opts.title) + '">' +
      '<div class="sheet-head"><h2 style="font-size:1.15rem">' + K.esc(opts.title) + '</h2>' +
      '<button type="button" aria-label="Close" data-close>' + K.icon('x') + '</button></div>' +
      '<div class="sheet-body">' + opts.html + '</div></div>';
    var previous = document.activeElement;
    function close() {
      document.removeEventListener('keydown', onKey);
      back.remove();
      if (previous && previous.focus) previous.focus();
    }
    function onKey(e) { if (e.key === 'Escape') close(); }
    back.addEventListener('click', function (e) { if (e.target === back || e.target.closest('[data-close]')) close(); });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    var first = K.$('button, a, input, select', K.$('.sheet-body', back));
    (first || K.$('[data-close]', back)).focus();
    if (opts.onMount) opts.onMount(back, close);
    return close;
  };
})(typeof window !== 'undefined' ? window : globalThis);
