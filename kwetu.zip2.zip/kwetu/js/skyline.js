/* Draws the KWETU night-city skyline into an <svg class="skyline">. Used by the splash and the landing hero. */
(function (global) {
  'use strict';
  var K = global.KWETU;

  K.skyline = function (svg, startSeed) {
    var NS = 'http://www.w3.org/2000/svg';
    var W = 400, H = 400;
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    svg.setAttribute('preserveAspectRatio', 'xMidYMax slice');
    svg.setAttribute('aria-hidden', 'true');

    var seed = startSeed || 7; // deterministic, so the skyline looks the same every visit
    function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
    function el(name, attrs) {
      var n = document.createElementNS(NS, name);
      for (var k in attrs) n.setAttribute(k, attrs[k]);
      svg.appendChild(n);
      return n;
    }

    var colors = ['#2dd4bf', '#2dd4bf', '#7c3aed', '#a78bfa'];
    var x = -10;
    while (x < W + 10) {
      var w = 28 + rnd() * 44, h = 90 + rnd() * 230, top = H - h;
      el('rect', { x: x, y: top, width: w, height: h, fill: '#0b1233', stroke: '#1d2a66', 'stroke-width': 0.8, opacity: 0.85 });
      for (var ly = top + 14; ly < H; ly += 22 + rnd() * 18) {
        el('line', { x1: x, x2: x + w, y1: ly, y2: ly, stroke: '#1d2a66', 'stroke-width': 0.5, opacity: 0.6 });
      }
      var cols = Math.floor(w / 9), rows = Math.floor(h / 13);
      for (var r = 0; r < rows; r++) {
        for (var c = 0; c < cols; c++) {
          if (rnd() > 0.1) continue;
          var win = el('rect', { x: x + 4 + c * 9, y: top + 6 + r * 13, width: 4, height: 5, fill: colors[Math.floor(rnd() * colors.length)], opacity: 0.9 });
          win.style.animation = 'twinkle ' + (3 + rnd() * 5).toFixed(1) + 's ' + (rnd() * 4).toFixed(1) + 's ease-in-out infinite';
        }
      }
      x += w + 2 + rnd() * 6;
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
