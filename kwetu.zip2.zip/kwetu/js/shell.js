/*
 * KWETU app shell and page boot.
 *
 * Any page with <body data-page="name"> is booted here:
 *   - data-requires-auth   -> redirects to login.html if nobody is signed in
 *   - data-app-shell       -> mounts the header, town selector and bottom navigation
 * Then it calls KWETU.pages[name].init(session). To add a page: add the HTML file, add
 * js/pages/<name>.js that sets KWETU.pages.<name> = { init }, and include both scripts.
 */
(function (global) {
  'use strict';
  var K = global.KWETU;
  var TOWN_KEY = 'kwetu.town';

  K.towns = [];
  K.session = null;

  /* ---------- Selected town (device preference; falls back to the configured default) ---------- */
  K.town = {
    slug: function () { return K.store.get(TOWN_KEY, null) || K.config.defaultTownSlug; },
    find: function (slug) { return K.towns.filter(function (t) { return t.slug === slug; })[0] || null; },
    current: function () { return K.town.find(K.town.slug()) || K.town.find(K.config.defaultTownSlug) || K.towns[0] || null; },
    name: function () { var t = K.town.current(); return t ? t.name : 'Choose town'; },
    set: function (slug) {
      K.store.set(TOWN_KEY, slug);
      document.dispatchEvent(new CustomEvent('kwetu:townchange', { detail: { slug: slug } }));
    }
  };

  var NAV = [
    { id: 'home', label: 'Home', icon: 'home', href: 'home.html' },
    { id: 'explore', label: 'Explore', icon: 'compass', href: 'explore.html' },
    { id: 'create', label: 'Create', icon: 'plus', create: true },
    { id: 'activity', label: 'Activity', icon: 'bell', href: 'activity.html' },
    { id: 'profile', label: 'Profile', icon: 'user', href: 'profile.html' }
  ];

  var CREATE_OPTIONS = [
    { icon: 'edit', title: 'Social post', sub: 'Share something with your town' },
    { icon: 'briefcase', title: 'Service listing', sub: 'Offer wellness or other services' },
    { icon: 'music', title: 'Experience', sub: 'Karaoke nights, live music, outings' },
    { icon: 'ticket', title: 'Event', sub: 'Publish an event and sell tickets' },
    { icon: 'store', title: 'Business page', sub: 'Put your venue or business on KWETU' }
  ];

  function openTownSheet() {
    K.sheet({
      title: 'Choose your town',
      html: '<div class="list" id="town-list" style="border:1px solid var(--line);border-radius:12px;overflow:hidden"></div>' +
        '<p class="meta" style="margin-top:12px">More towns and neighbourhoods are added as KWETU grows.</p>',
      onMount: function (el, close) {
        var list = K.$('#town-list', el);
        var current = K.town.slug();
        list.innerHTML = K.towns.map(function (t) {
          return '<button type="button" class="list-item" data-slug="' + K.esc(t.slug) + '">' +
            '<span class="ico">' + K.icon('pin') + '</span>' +
            '<span class="grow"><span class="title">' + K.esc(t.name) + '</span><br><span class="meta">' + K.esc(t.county || '') + '</span></span>' +
            (t.slug === current ? '<span style="color:var(--ok)">' + K.icon('check', 20) + '</span>' : '') + '</button>';
        }).join('');
        list.addEventListener('click', function (e) {
          var b = e.target.closest('[data-slug]');
          if (!b) return;
          K.town.set(b.getAttribute('data-slug'));
          close();
        });
      }
    });
  }

  function openCreateSheet() {
    var signedIn = !!K.session;
    K.sheet({
      title: 'Create',
      html: (signedIn ? '' : '<div class="notice">Log in or create an account to publish on KWETU. <a href="login.html" style="font-weight:700">Log in</a></div>') +
        '<div class="list" style="border:1px solid var(--line);border-radius:12px;overflow:hidden">' +
        CREATE_OPTIONS.map(function (o, i) {
          return '<button type="button" class="list-item" data-i="' + i + '"><span class="ico">' + K.icon(o.icon) + '</span>' +
            '<span class="grow"><span class="title">' + K.esc(o.title) + '</span><br><span class="meta">' + K.esc(o.sub) + '</span></span>' +
            '<span class="badge soon">Soon</span></button>';
        }).join('') + '</div>',
      onMount: function (el, close) {
        el.addEventListener('click', function (e) {
          var b = e.target.closest('[data-i]');
          if (!b) return;
          var o = CREATE_OPTIONS[+b.getAttribute('data-i')];
          close();
          K.toast(signedIn ? o.title + ' creation arrives in an upcoming block.' : 'Please log in first.');
        });
      }
    });
  }

  K.shell = {
    mount: function (page) {
      document.body.classList.add('app');

      var header = document.createElement('header');
      header.className = 'app-header';
      header.innerHTML = '<div class="inner">' +
        '<a href="home.html" aria-label="KWETU home" style="text-decoration:none;color:#fff">' + K.wordmark() + '</a>' +
        '<span class="grow"></span>' +
        (K.isDemo() ? '<span class="demo-chip" title="Data is stored on this device only">DEMO</span>' : '') +
        '<button type="button" class="town-btn" id="town-btn" aria-label="Change town">' + K.icon('pin', 18) + '<span id="town-name">' + K.esc(K.town.name()) + '</span></button>' +
        '</div>';
      document.body.insertBefore(header, document.body.firstChild);

      var nav = document.createElement('nav');
      nav.className = 'bottom-nav';
      nav.setAttribute('aria-label', 'Main');
      nav.innerHTML = NAV.map(function (n) {
        if (n.create) return '<button type="button" id="nav-create" aria-label="Create"><span class="plus">' + K.icon('plus') + '</span><span>' + n.label + '</span></button>';
        return '<a href="' + n.href + '"' + (n.id === page ? ' class="active" aria-current="page"' : '') + '>' + K.icon(n.icon) + '<span>' + n.label + '</span></a>';
      }).join('');
      document.body.appendChild(nav);

      K.$('#town-btn').addEventListener('click', openTownSheet);
      K.$('#nav-create').addEventListener('click', openCreateSheet);
      document.addEventListener('kwetu:townchange', function () { K.$('#town-name').textContent = K.town.name(); });
    }
  };

  /* ---------- Page boot ---------- */
  function showFatal(message) {
    var host = K.$('#app') || document.body;
    host.innerHTML = '<div class="page"><div class="form-error" role="alert">' + K.esc(message) + '</div></div>';
  }

  function boot() {
    var page = document.body.getAttribute('data-page');
    if (!page) return; // static pages (legal) need no data

    K.data.init()
      .then(function () { return Promise.all([K.data.getSession(), K.data.listTowns()]); })
      .then(function (res) {
        K.session = res[0];
        K.towns = res[1];

        if (document.body.hasAttribute('data-requires-auth') && !K.session) {
          var here = (location.pathname.split('/').pop() || 'home.html') + location.search;
          location.replace('login.html?next=' + encodeURIComponent(here));
          return;
        }
        if (document.body.hasAttribute('data-app-shell')) K.shell.mount(page);
        if (K.pages[page] && K.pages[page].init) K.pages[page].init(K.session);
      })
      .catch(function (err) { showFatal(err && err.message ? err.message : 'Something went wrong while loading KWETU.'); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(typeof window !== 'undefined' ? window : globalThis);
