/* home.html: location selector (in the shell), search, category shortcuts and discovery sections. */
(function (global) {
  'use strict';
  var K = global.KWETU;

  function emptyState(icon, title, text) {
    return '<div class="card empty"><div class="ico">' + K.icon(icon) + '</div><h3>' + K.esc(title) + '</h3><p>' + K.esc(text) + '</p></div>';
  }

  function sampleTile(title, meta, alt) {
    return '<article class="card"><div class="tile-cover' + (alt ? ' alt' : '') + '"><span class="badge sample">Sample</span></div>' +
      '<div class="tile-body"><h3>' + K.esc(title) + '</h3><p class="meta">' + K.esc(meta) + '</p></div></article>';
  }

  function render(profile) {
    var town = K.town.name();
    var first = profile && profile.displayName ? profile.displayName.split(' ')[0] : '';
    var host = K.$('#app');

    host.innerHTML =
      '<div class="page">' +
      '<h1 class="page-title">' + (first ? 'Hi ' + K.esc(first) + ' 👋' : 'Welcome') + '</h1>' +
      '<p class="page-sub">What is happening in ' + K.esc(town) + '?</p>' +

      '<form class="searchbar" id="home-search" role="search">' + K.icon('search') +
      '<label class="sr-only" for="home-q">Search KWETU</label>' +
      '<input id="home-q" type="search" placeholder="Search people, events, services, rides" autocomplete="off"></form>' +

      '<section class="section" aria-label="Categories"><div class="cat-row">' +
      K.categories.map(function (c) {
        return '<a class="cat" href="explore.html?cat=' + c.slug + '"><span class="ico">' + K.icon(c.icon) + '</span>' + K.esc(c.label) + '</a>';
      }).join('') + '</div></section>' +

      (!K.session ? '<div class="notice">Browsing as a guest. <a href="register.html" style="font-weight:700">Create a free account</a> to book, buy tickets and post.</div>' : '') +

      '<section class="section"><div class="section-head"><h2>Available now</h2></div>' +
      emptyState('users', 'No one is listed as available in ' + town + ' yet', 'Providers appear here only when they switch themselves to available. Nothing is shown unless it is true right now.') +
      '</section>' +

      '<section class="section"><div class="section-head"><h2>Nearby experiences</h2><a href="explore.html?cat=experiences">See all</a></div>' +
      '<div class="h-scroll">' + sampleTile('Wednesday Karaoke Night', 'Sample venue · Every Wednesday · 8 PM', false) + sampleTile('Live Music Friday', 'Sample venue · Fridays · 9 PM', true) + '</div>' +
      '<p class="meta" style="margin-top:8px">Sample cards show how listings will look. Real experiences appear as venues join.</p></section>' +

      '<section class="section"><div class="section-head"><h2>Upcoming events</h2><a href="explore.html?cat=events">See all</a></div>' +
      '<div class="h-scroll">' + sampleTile('Sunday Pool Party', 'Sample event · KSh 500 · Sample date', true) + sampleTile('Campus Concert Night', 'Sample event · KSh 300 · Sample date', false) + '</div>' +
      '<p class="meta" style="margin-top:8px">Sample content, not real events. Organisers can publish for free once event publishing ships.</p></section>' +

      '<section class="section"><div class="section-head"><h2>Local feed</h2></div>' +
      emptyState('edit', 'The feed starts here', 'Posts from people and businesses you follow, plus local events and promotions, will appear in this feed.') +
      '</section></div>';

    K.$('#home-search').addEventListener('submit', function (e) {
      e.preventDefault();
      var q = K.$('#home-q').value.trim();
      location.href = 'explore.html' + (q ? '?q=' + encodeURIComponent(q) : '');
    });
  }

  K.pages.home = {
    init: function (session) {
      var load = session ? K.data.getProfile().catch(function () { return null; }) : Promise.resolve(null);
      load.then(function (profile) {
        render(profile);
        document.addEventListener('kwetu:townchange', function () { render(profile); });
      });
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
