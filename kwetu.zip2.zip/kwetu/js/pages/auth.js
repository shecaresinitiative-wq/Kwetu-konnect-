/* login.html and register.html. */
(function (global) {
  'use strict';
  var K = global.KWETU;

  function nextTarget() {
    var m = /[?&]next=([^&]+)/.exec(location.search);
    return K.safeNext(m ? decodeURIComponent(m[1]) : '', 'home.html');
  }
  function showError(form, message) {
    var box = K.$('.form-error', form);
    if (!box) { box = document.createElement('div'); box.className = 'form-error'; box.setAttribute('role', 'alert'); form.insertBefore(box, form.firstChild); }
    box.textContent = message;
    box.scrollIntoView({ block: 'nearest' });
  }
  function clearError(form) { var b = K.$('.form-error', form); if (b) b.remove(); }
  function setBusy(btn, busy, label) { btn.disabled = busy; if (label) btn.textContent = label; }
  function focusFirstInvalid(form) { var bad = K.$('[aria-invalid="true"]', form); if (bad) bad.focus(); }

  /* ---------- Login ---------- */
  K.pages.login = {
    init: function (session) {
      if (session) { location.replace(nextTarget()); return; }
      var form = K.$('#login-form');
      var btn = K.$('button[type=submit]', form);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        clearError(form);
        var email = form.email, pass = form.password, ok = true;
        K.fieldError(email, K.validate.email(email.value) ? '' : 'Enter a valid email address.'); ok = ok && K.validate.email(email.value);
        K.fieldError(pass, pass.value ? '' : 'Enter your password.'); ok = ok && !!pass.value;
        if (!ok) { focusFirstInvalid(form); return; }

        setBusy(btn, true, 'Logging in…');
        K.data.signIn({ email: email.value, password: pass.value })
          .then(function () { location.href = nextTarget(); })
          .catch(function (err) { showError(form, err.message); setBusy(btn, false, 'Log in'); });
      });
    }
  };

  /* ---------- Register ---------- */
  K.pages.register = {
    init: function (session) {
      if (session) { location.replace(nextTarget()); return; }
      var form = K.$('#register-form');
      var btn = K.$('button[type=submit]', form);

      // Town list comes from the data layer; the default is configured, not hardcoded.
      form.town.innerHTML = K.towns.map(function (t) {
        return '<option value="' + K.esc(t.slug) + '">' + K.esc(t.name) + '</option>';
      }).join('');
      form.town.value = K.town.slug();

      // Date of birth must be at least minAge years ago.
      var d = new Date();
      d.setUTCFullYear(d.getUTCFullYear() - K.config.minAge);
      form.dob.max = d.toISOString().slice(0, 10);
      form.dob.min = '1900-01-01';

      form.addEventListener('submit', function (e) {
        e.preventDefault();
        clearError(form);
        var f = form, ok = true;
        function check(input, valid, message) { K.fieldError(input, valid ? '' : message); if (!valid) ok = false; }

        check(f.displayName, K.validate.displayName(f.displayName.value), 'Enter a name between 2 and 60 characters.');
        check(f.email, K.validate.email(f.email.value), 'Enter a valid email address.');
        var phone = K.validate.phone(f.phone.value);
        check(f.phone, !!phone, 'Enter a valid Kenyan mobile number, e.g. 0712 345 678.');
        var age = K.validate.age(f.dob.value);
        check(f.dob, age !== null && age >= K.config.minAge && age < 120, 'You must be ' + K.config.minAge + ' or older to join KWETU.');
        check(f.town, !!f.town.value, 'Choose your town.');
        check(f.password, K.validate.password(f.password.value), 'Use at least 8 characters, with a letter and a number.');
        check(f.confirm, f.confirm.value === f.password.value, 'Passwords do not match.');
        check(f.agree, f.agree.checked, 'Please confirm to continue.');
        if (!ok) { focusFirstInvalid(form); return; }

        setBusy(btn, true, 'Creating account…');
        K.data.signUp({
          displayName: f.displayName.value, email: f.email.value, phone: phone,
          dob: f.dob.value, townSlug: f.town.value, password: f.password.value
        }).then(function (res) {
          K.town.set(f.town.value);
          if (res.needsConfirmation) {
            form.innerHTML = '<div class="form-note" role="status"><strong>Check your email.</strong> We sent a confirmation link to ' + K.esc(f.email.value) + '. Open it, then <a href="login.html">log in</a>.</div>';
            return;
          }
          location.href = nextTarget();
        }).catch(function (err) { showError(form, err.message); setBusy(btn, false, 'Create account'); });
      });
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
