/* profile.html: view and edit your profile, see account capabilities, sign out. */
(function (global) {
  'use strict';
  var K = global.KWETU;

  var CAPABILITIES = [
    { role: 'user', title: 'Member', sub: 'Browse, post, book, buy tickets, request rides', icon: 'user' },
    { role: 'service_provider', title: 'Service provider', sub: 'Publish wellness and other services', icon: 'briefcase' },
    { role: 'companion_provider', title: 'Companion provider', sub: 'Adults only, identity verification required', icon: 'users' },
    { role: 'business_owner', title: 'Business owner', sub: 'Venue page, promotions, recurring activities', icon: 'store' },
    { role: 'event_organiser', title: 'Event organiser', sub: 'Publish events, sell and scan tickets', icon: 'ticket' },
    { role: 'transport_operator', title: 'Transport operator', sub: 'Receive and manage ride requests', icon: 'car' }
  ];

  function initials(name) {
    return String(name || '?').trim().split(/\s+/).slice(0, 2).map(function (w) { return w.charAt(0).toUpperCase(); }).join('');
  }
  function maskPhone(p) { return p && p.length > 8 ? p.slice(0, 6) + '•••' + p.slice(-3) : (p || 'Not set'); }
  function memberSince(iso) {
    var d = new Date(iso);
    return isNaN(d) ? '' : d.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  }

  function render(p) {
    var activeRoles = {};
    (p.roles || []).forEach(function (r) { activeRoles[r.role] = r.status; });

    K.$('#app').innerHTML =
      '<div class="page">' +
      (p.demo ? '<div class="notice warn"><strong>Demo mode.</strong> This account lives only in this browser. Connect Supabase in <code>js/config.js</code> for real accounts.</div>' : '') +

      '<div style="display:flex;gap:16px;align-items:center;margin-bottom:22px">' +
      '<div class="avatar" aria-hidden="true">' + K.esc(initials(p.displayName)) + '</div>' +
      '<div><h1 class="page-title" style="margin:0">' + K.esc(p.displayName) + '</h1>' +
      '<p class="meta">' + K.esc(p.email) + '<br>' + K.esc(p.townName || '') + (p.createdAt ? ' · Member since ' + K.esc(memberSince(p.createdAt)) : '') + '</p></div></div>' +

      '<section class="section"><div class="section-head"><h2>Edit profile</h2></div><div class="card card-pad">' +
      '<form id="profile-form" novalidate>' +
      '<div class="field"><label for="pf-name">Display name</label><input id="pf-name" name="displayName" maxlength="60" value="' + K.esc(p.displayName) + '" autocomplete="name"></div>' +
      '<div class="field"><label for="pf-town">Town</label><select id="pf-town" name="town"></select></div>' +
      '<div class="field"><label for="pf-bio">Bio</label><textarea id="pf-bio" name="bio" maxlength="500" placeholder="A few words about you">' + K.esc(p.bio) + '</textarea><span class="hint">Up to 500 characters. Shown on your public profile.</span></div>' +
      '<div class="field"><label>Phone</label><input value="' + K.esc(maskPhone(p.phone)) + '" disabled><span class="hint">Only you can see your phone number. Verification arrives in a later block.</span></div>' +
      '<button class="btn btn-primary" type="submit">Save changes</button></form></div></section>' +

      '<section class="section"><div class="section-head"><h2>Account capabilities</h2></div>' +
      '<p class="meta" style="margin-bottom:10px">One login, many roles. Extra capabilities are activated from here once their blocks ship, and higher-risk ones need verification.</p>' +
      '<div class="card"><div class="list">' +
      CAPABILITIES.map(function (c) {
        var on = activeRoles[c.role] === 'active';
        return '<div class="list-item"><span class="ico">' + K.icon(c.icon) + '</span><span class="grow"><span class="title">' + K.esc(c.title) + '</span><br><span class="meta">' + K.esc(c.sub) + '</span></span>' +
          (on ? '<span class="badge" style="background:var(--ok)">Active</span>' : '<span class="badge soon">Soon</span>') + '</div>';
      }).join('') + '</div></div></section>' +

      '<section class="section"><div class="card"><div class="list">' +
      '<a class="list-item" href="guidelines.html"><span class="ico">' + K.icon('shield') + '</span><span class="grow"><span class="title">Community guidelines and safety</span></span>' + K.icon('chevron', 20) + '</a>' +
      '<a class="list-item" href="terms.html"><span class="ico">' + K.icon('doc') + '</span><span class="grow"><span class="title">Terms of use</span></span>' + K.icon('chevron', 20) + '</a>' +
      '<a class="list-item" href="privacy.html"><span class="ico">' + K.icon('doc') + '</span><span class="grow"><span class="title">Privacy</span></span>' + K.icon('chevron', 20) + '</a>' +
      '<button class="list-item" id="signout" type="button"><span class="ico">' + K.icon('logout') + '</span><span class="grow"><span class="title">Log out</span></span></button>' +
      '</div></div></section></div>';

    var form = K.$('#profile-form');
    form.town.innerHTML = K.towns.map(function (t) { return '<option value="' + K.esc(t.slug) + '">' + K.esc(t.name) + '</option>'; }).join('');
    form.town.value = p.townSlug || K.town.slug();

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var ok = K.validate.displayName(form.displayName.value);
      K.fieldError(form.displayName, ok ? '' : 'Enter a name between 2 and 60 characters.');
      if (!ok) { form.displayName.focus(); return; }
      var btn = K.$('button[type=submit]', form);
      btn.disabled = true; btn.textContent = 'Saving…';
      K.data.updateProfile({ displayName: form.displayName.value, bio: form.bio.value, townSlug: form.town.value })
        .then(function (updated) { K.town.set(updated.townSlug); K.toast('Profile saved.'); render(updated); })
        .catch(function (err) { K.toast(err.message, 'error'); btn.disabled = false; btn.textContent = 'Save changes'; });
    });

    K.$('#signout').addEventListener('click', function () {
      K.data.signOut().then(function () { location.href = 'index.html#top'; });
    });
  }

  K.pages.profile = {
    init: function () {
      K.data.getProfile()
        .then(function (p) { if (!p) { location.replace('login.html?next=profile.html'); return; } render(p); })
        .catch(function (err) { K.$('#app').innerHTML = '<div class="page"><div class="form-error">' + K.esc(err.message) + '</div></div>'; });
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
