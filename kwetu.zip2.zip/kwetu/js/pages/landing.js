/* index.html: splash screen, then the landing page. */
(function (global) {
  'use strict';
  var K = global.KWETU;
  var SEEN_KEY = 'kwetu.splashSeen';

  function seenThisSession() {
    try { return global.sessionStorage.getItem(SEEN_KEY) === '1'; } catch (e) { return false; }
  }
  function markSeen() {
    try { global.sessionStorage.setItem(SEEN_KEY, '1'); } catch (e) { /* ignore */ }
  }

  function setupSplash() {
    var splash = K.$('#splash');
    if (!splash) return;
    // Skip the splash for returning visitors in this session, or when linking to a section (#pillars etc.)
    if (seenThisSession() || location.hash) { splash.remove(); document.body.classList.remove('splash-open'); return; }

    function enter() {
      markSeen();
      splash.classList.add('leaving');
      document.body.classList.remove('splash-open');
      setTimeout(function () { splash.remove(); }, 650);
    }
    splash.addEventListener('click', enter);
    splash.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); enter(); } });
    splash.focus();
  }

  K.pages.landing = {
    init: function (session) {
      K.$$('svg.skyline').forEach(function (svg, i) { K.skyline(svg, 7 + i * 11); });
      setupSplash();

      // Signed-in visitors get a direct way back into the app.
      if (session) {
        K.$$('[data-guest-only]').forEach(function (n) { n.hidden = true; });
        K.$$('[data-user-only]').forEach(function (n) { n.hidden = false; });
      }
      K.$$('[data-year]').forEach(function (n) { n.textContent = new Date().getFullYear(); });
    }
  };

  // The splash must work even if the data layer is slow or unavailable, so draw it immediately.
  function early() {
    K.$$('#splash svg.skyline').forEach(function (svg) { K.skyline(svg, 7); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', early); else early();
})(typeof window !== 'undefined' ? window : globalThis);
