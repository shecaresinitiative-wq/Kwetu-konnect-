/* activity.html: notification centre. Real notifications arrive with the bookings, tickets and rides blocks. */
(function (global) {
  'use strict';
  var K = global.KWETU;

  K.pages.activity = {
    init: function () {
      K.$('#app').innerHTML =
        '<div class="page"><h1 class="page-title">Activity</h1>' +
        '<p class="page-sub">Booking updates, ticket confirmations, ride requests and new followers.</p>' +
        '<div class="card empty"><div class="ico">' + K.icon('bell') + '</div>' +
        '<h3>You are all caught up</h3>' +
        '<p>Nothing new yet. When someone responds to a booking, a ticket is confirmed or a provider becomes available, you will see it here.</p></div>' +
        '<div class="notice" style="margin-top:18px">Coming with later blocks: notification preferences, and push, email and SMS delivery.</div></div>';
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
