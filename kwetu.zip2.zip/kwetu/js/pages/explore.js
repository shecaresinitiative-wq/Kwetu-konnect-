/* explore.html: browse by category and search. Listings arrive in later blocks, so results are honest empty states. */
(function (global) {
  'use strict';
  var K = global.KWETU;
  var state = { q: '', cat: '' };

  function readUrl() {
    var p = new URLSearchParams(location.search);
    state.q = (p.get('q') || '').trim();
    var c = p.get('cat') || '';
    state.cat = K.categoryBySlug(c) ? c : '';
  }
  function writeUrl() {
    var p = new URLSearchParams();
    if (state.q) p.set('q', state.q);
    if (state.cat) p.set('cat', state.cat);
    var qs = p.toString();
    try { history.replaceState(null, '', 'explore.html' + (qs ? '?' + qs : '')); } catch (e) { /* file:// may block this */ }
  }

  function matches(c) {
    if (state.cat && c.slug !== state.cat) return false;
    if (!state.q) return true;
    var hay = (c.label + ' ' + c.blurb + ' ' + c.slug).toLowerCase();
    return state.q.toLowerCase().split(/\s+/).every(function (w) { return hay.indexOf(w) !== -1; });
  }

  function render() {
    var town = K.town.name();
    var host = K.$('#app');
    var cats = K.categories.filter(matches);
    var active = K.categoryBySlug(state.cat);

    host.innerHTML =
      '<div class="page"><h1 class="page-title">Explore ' + K.esc(town) + '</h1>' +
      '<p class="page-sub">Browse by category, or search. Change town from the pin at the top.</p>' +
      '<form class="searchbar" id="ex-search" role="search">' + K.icon('search') +
      '<label class="sr-only" for="ex-q">Search</label><input id="ex-q" type="search" value="' + K.esc(state.q) + '" placeholder="Search people, events, services, rides" autocomplete="off"></form>' +

      '<div class="chips" style="margin-top:14px" role="group" aria-label="Filter by category">' +
      '<button type="button" class="chip" data-cat="" aria-pressed="' + (!state.cat) + '">All</button>' +
      K.categories.map(function (c) { return '<button type="button" class="chip" data-cat="' + c.slug + '" aria-pressed="' + (state.cat === c.slug) + '">' + K.esc(c.label) + '</button>'; }).join('') + '</div>' +

      (active && active.note ? '<div class="notice warn" style="margin-top:14px">' + K.esc(active.note) + '</div>' : '') +

      '<section class="section"><div class="card"><div class="list">' +
      (cats.length ? cats.map(function (c) {
        return '<button type="button" class="list-item" data-pick="' + c.slug + '"><span class="ico">' + K.icon(c.icon) + '</span>' +
          '<span class="grow"><span class="title">' + K.esc(c.label) + (c.adultsOnly ? ' · 18+' : '') + '</span><br><span class="meta">' + K.esc(c.blurb) + '</span></span>' + K.icon('chevron', 20) + '</button>';
      }).join('') : '<div class="empty"><h3>No matching category</h3><p>Try a different word, like “events”, “massage” or “boda”.</p></div>') +
      '</div></div></section>' +

      '<section class="section"><div class="card empty"><div class="ico">' + K.icon('pin') + '</div>' +
      '<h3>No listings in ' + K.esc(town) + ' yet</h3>' +
      '<p>' + (state.q ? 'Nothing matches “' + K.esc(state.q) + '” right now. ' : '') + 'Listings from real providers, venues and organisers will show here as they join. We never show people or services as available unless they are.</p></div></section></div>';

    K.$('#ex-search').addEventListener('submit', function (e) {
      e.preventDefault(); state.q = K.$('#ex-q').value.trim(); writeUrl(); render();
    });
  }

  K.pages.explore = {
    init: function () {
      readUrl(); render();
      document.addEventListener('kwetu:townchange', render);
      // One delegated listener for the whole page life; render() only replaces the inner HTML.
      K.$('#app').addEventListener('click', function (e) {
        var chip = e.target.closest('[data-cat]');
        var pick = e.target.closest('[data-pick]');
        if (!chip && !pick) return;
        state.cat = chip ? chip.getAttribute('data-cat') : pick.getAttribute('data-pick');
        writeUrl(); render();
      });
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
