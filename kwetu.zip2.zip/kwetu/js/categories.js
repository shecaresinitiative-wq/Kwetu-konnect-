/*
 * The KWETU pillars as browsable categories. One list, used by Home, Explore and (later) Create.
 * To add a category: add an entry here. Nothing else needs to change.
 */
(function (global) {
  'use strict';
  var K = global.KWETU;

  K.categories = [
    { slug: 'companionship', label: 'Companions', icon: 'users', adultsOnly: true,
      blurb: 'Consenting adults offering companionship, with clear categories, prices and booking conditions.',
      note: 'Adults only (18+). Companionship does not automatically mean sexual services, and payment never guarantees intimacy or consent.' },
    { slug: 'experiences', label: 'Experiences', icon: 'music',
      blurb: 'Clubs, karaoke nights, live music, restaurants, outings and local attractions.' },
    { slug: 'events', label: 'Events', icon: 'ticket',
      blurb: 'Parties, concerts and gatherings with digital QR tickets.' },
    { slug: 'wellness', label: 'Wellness', icon: 'spa',
      blurb: 'Massage, spa, beauty and personal care from verified providers.' },
    { slug: 'transport', label: 'Transport', icon: 'car',
      blurb: 'Boda boda riders, private drivers and local transport operators.' },
    { slug: 'businesses', label: 'Businesses', icon: 'store',
      blurb: 'Venues and local businesses, with their promotions and recurring activities.' }
  ];

  K.categoryBySlug = function (slug) {
    return K.categories.filter(function (c) { return c.slug === slug; })[0] || null;
  };
})(typeof window !== 'undefined' ? window : globalThis);
