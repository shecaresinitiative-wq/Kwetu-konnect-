-- =====================================================================
-- KWETU  |  Migration 0001: Foundation
-- Towns, profiles, private profile data, roles, audit log, Row Level Security.
-- Run once, in order. Later blocks add NEW migration files; never edit this one after it has run.
-- =====================================================================

-- ---------- Enums ----------
create type public.app_role as enum (
  'user', 'service_provider', 'companion_provider',
  'business_owner', 'event_organiser', 'transport_operator', 'admin'
);
create type public.account_status as enum ('active', 'suspended', 'deactivated');

-- ---------- Shared helper: keep updated_at current ----------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------- Towns and neighbourhoods (multi-town from day one; no town is hardcoded) ----------
create table public.towns (
  id          uuid primary key default gen_random_uuid(),
  slug        text not null unique check (slug ~ '^[a-z0-9-]+$'),
  name        text not null,
  county      text,
  country_code char(2) not null default 'KE',
  latitude    numeric(9,6),
  longitude   numeric(9,6),
  is_active   boolean not null default true,
  is_default  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
-- At most one default town.
create unique index towns_single_default on public.towns (is_default) where is_default;
create trigger towns_updated_at before update on public.towns
  for each row execute function public.set_updated_at();

create table public.neighbourhoods (
  id          uuid primary key default gen_random_uuid(),
  town_id     uuid not null references public.towns(id) on delete cascade,
  slug        text not null check (slug ~ '^[a-z0-9-]+$'),
  name        text not null,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (town_id, slug)
);
create index neighbourhoods_town_idx on public.neighbourhoods (town_id);
create trigger neighbourhoods_updated_at before update on public.neighbourhoods
  for each row execute function public.set_updated_at();

-- ---------- Profiles: public-facing identity (one row per auth user) ----------
create table public.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  display_name    text not null check (char_length(display_name) between 2 and 60),
  username        text unique check (username ~ '^[a-z0-9_]{3,30}$'),
  bio             text check (char_length(bio) <= 500),
  avatar_url      text,
  cover_url       text,
  town_id         uuid references public.towns(id),
  neighbourhood_id uuid references public.neighbourhoods(id),
  status          public.account_status not null default 'active',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index profiles_town_idx on public.profiles (town_id);
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

-- ---------- Private profile data: only the owner and admins can ever read this ----------
create table public.profile_private (
  user_id           uuid primary key references public.profiles(id) on delete cascade,
  phone_e164        text unique check (phone_e164 ~ '^\+254[17][0-9]{8}$'),
  date_of_birth     date,
  phone_verified_at timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create trigger profile_private_updated_at before update on public.profile_private
  for each row execute function public.set_updated_at();

-- ---------- Roles: one identity, many capabilities ----------
create table public.user_roles (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  role        public.app_role not null,
  status      text not null default 'pending' check (status in ('pending', 'active', 'revoked')),
  granted_by  uuid references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (user_id, role)
);
create index user_roles_user_idx on public.user_roles (user_id);
create trigger user_roles_updated_at before update on public.user_roles
  for each row execute function public.set_updated_at();

-- ---------- Audit log: written only by the backend and triggers, readable only by admins ----------
create table public.audit_logs (
  id          bigint generated always as identity primary key,
  actor_id    uuid references auth.users(id) on delete set null,
  action      text not null,
  entity_type text,
  entity_id   text,
  details     jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);
create index audit_logs_entity_idx on public.audit_logs (entity_type, entity_id);
create index audit_logs_created_idx on public.audit_logs (created_at desc);

-- ---------- Role helpers (SECURITY DEFINER so policies can check roles without recursion) ----------
create or replace function public.has_role(_role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = _role and status = 'active'
  );
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.has_role('admin'::public.app_role);
$$;

-- ---------- New-user trigger: creates profile, private data and base role ----------
-- Server-side age gate: sign-up FAILS unless the date of birth shows the person is 18 or older.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  meta        jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  v_dob       date;
  v_name      text;
  v_phone     text;
  v_town_id   uuid;
begin
  begin
    v_dob := (meta->>'date_of_birth')::date;
  exception when others then
    v_dob := null;
  end;
  if v_dob is null or v_dob > (current_date - interval '18 years')::date then
    raise exception 'KWETU: you must be 18 or older to create an account';
  end if;

  v_name := nullif(btrim(coalesce(meta->>'display_name', '')), '');
  if v_name is null or char_length(v_name) < 2 then
    v_name := coalesce(nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'Member');
    if char_length(v_name) < 2 then v_name := 'Member'; end if;
  end if;
  v_name := left(v_name, 60);

  v_phone := meta->>'phone';
  if v_phone is null or v_phone !~ '^\+254[17][0-9]{8}$' then v_phone := null; end if;

  select id into v_town_id from public.towns where slug = meta->>'town_slug' and is_active;
  if v_town_id is null then
    select id into v_town_id from public.towns where is_default limit 1;
  end if;

  insert into public.profiles (id, display_name, town_id) values (new.id, v_name, v_town_id);
  insert into public.profile_private (user_id, phone_e164, date_of_birth) values (new.id, v_phone, v_dob);
  insert into public.user_roles (user_id, role, status) values (new.id, 'user', 'active');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Column protection: clients cannot self-suspend, self-verify or self-promote ----------
create or replace function public.protect_profile_status()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  -- auth.uid() is null for the backend (service role) and migrations; those are trusted.
  if auth.uid() is not null and not public.is_admin() and new.status is distinct from old.status then
    raise exception 'KWETU: account status can only be changed by an administrator';
  end if;
  return new;
end;
$$;
create trigger profiles_protect_status before update on public.profiles
  for each row execute function public.protect_profile_status();

create or replace function public.protect_private_columns()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.phone_verified_at is distinct from old.phone_verified_at then
      raise exception 'KWETU: phone verification can only be set by the backend';
    end if;
    if new.date_of_birth is distinct from old.date_of_birth then
      raise exception 'KWETU: date of birth cannot be changed here';
    end if;
  end if;
  return new;
end;
$$;
create trigger profile_private_protect before update on public.profile_private
  for each row execute function public.protect_private_columns();

-- ---------- Audit every role change ----------
create or replace function public.log_role_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'DELETE' then
    insert into public.audit_logs (actor_id, action, entity_type, entity_id, details)
    values (auth.uid(), 'role_delete', 'user_roles', old.id::text,
            jsonb_build_object('user_id', old.user_id, 'role', old.role, 'status', old.status));
    return old;
  end if;

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'role_' || lower(tg_op), 'user_roles', new.id::text,
          jsonb_build_object('user_id', new.user_id, 'role', new.role, 'status', new.status));
  return new;
end;
$$;
create trigger user_roles_audit after insert or update or delete on public.user_roles
  for each row execute function public.log_role_change();

-- =====================================================================
-- Row Level Security: everything is locked down; policies open only what is needed.
-- =====================================================================
alter table public.towns          enable row level security;
alter table public.neighbourhoods enable row level security;
alter table public.profiles       enable row level security;
alter table public.profile_private enable row level security;
alter table public.user_roles     enable row level security;
alter table public.audit_logs     enable row level security;

-- Towns and neighbourhoods: anyone may read active ones; only admins change them.
create policy towns_read on public.towns for select to anon, authenticated using (is_active or public.is_admin());
create policy towns_admin_write on public.towns for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy neighbourhoods_read on public.neighbourhoods for select to anon, authenticated using (is_active or public.is_admin());
create policy neighbourhoods_admin_write on public.neighbourhoods for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Profiles: signed-in users can see active profiles; you can edit only your own; no client inserts or deletes.
create policy profiles_read on public.profiles for select to authenticated
  using (status = 'active' or id = auth.uid() or public.is_admin());
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

-- Private data: owner and admins only.
create policy profile_private_read on public.profile_private for select to authenticated
  using (user_id = auth.uid() or public.is_admin());
create policy profile_private_update_own on public.profile_private for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Roles: you can see your own; admins see all. NO client write policies, so role changes happen
-- only through the backend (Edge Functions with the service role) after verification.
create policy user_roles_read on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Audit log: admins read only. No client write policies.
create policy audit_logs_admin_read on public.audit_logs for select to authenticated using (public.is_admin());

-- Defence in depth: remove broad default grants, then grant exactly what the policies above rely on.
revoke all on public.audit_logs, public.user_roles, public.profile_private, public.profiles from anon;
revoke insert, delete on public.profiles from authenticated;
revoke insert, update, delete on public.user_roles from authenticated;
revoke insert, update, delete on public.audit_logs from authenticated;
revoke insert, delete on public.profile_private from authenticated;
