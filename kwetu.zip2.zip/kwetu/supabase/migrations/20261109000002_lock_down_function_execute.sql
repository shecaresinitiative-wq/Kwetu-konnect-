-- =====================================================================
-- KWETU  |  Migration 0002: stop exposing internal functions through the public API
--
-- Supabase publishes every function in the public schema as an RPC endpoint. Trigger helpers
-- and has_role() have no business being callable by visitors. Triggers still fire normally:
-- Postgres checks EXECUTE only when a trigger is created, not each time it runs.
--
-- is_admin() stays callable by anon and authenticated on purpose: Row Level Security policies
-- (for example "towns_read") evaluate it as the calling role. It only ever reports whether the
-- CALLER is an admin, so exposing it reveals nothing about anyone else.
-- =====================================================================

revoke execute on function public.handle_new_user()         from public, anon, authenticated;
revoke execute on function public.log_role_change()         from public, anon, authenticated;
revoke execute on function public.protect_profile_status()  from public, anon, authenticated;
revoke execute on function public.protect_private_columns() from public, anon, authenticated;

-- is_admin() calls has_role() as its definer, so callers never need EXECUTE on has_role() itself.
revoke execute on function public.has_role(public.app_role) from public, anon, authenticated;
