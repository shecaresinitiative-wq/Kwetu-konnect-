-- KWETU seed data: launch market and nearby towns. Safe to re-run.
-- Coordinates are approximate town centres. Neighbourhoods are added by admins as the platform grows.

insert into public.towns (slug, name, county, latitude, longitude, is_default) values
  ('bungoma',  'Bungoma',  'Bungoma',     0.5635,  34.5606, true),
  ('webuye',   'Webuye',   'Bungoma',     0.6074,  34.7712, false),
  ('kakamega', 'Kakamega', 'Kakamega',    0.2827,  34.7519, false),
  ('kitale',   'Kitale',   'Trans Nzoia', 1.0157,  35.0062, false),
  ('eldoret',  'Eldoret',  'Uasin Gishu', 0.5143,  35.2698, false),
  ('kisumu',   'Kisumu',   'Kisumu',     -0.0917,  34.7680, false),
  ('nairobi',  'Nairobi',  'Nairobi',    -1.2921,  36.8219, false),
  ('mombasa',  'Mombasa',  'Mombasa',    -4.0435,  39.6682, false)
on conflict (slug) do nothing;
