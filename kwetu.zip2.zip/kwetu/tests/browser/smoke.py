"""End-to-end browser smoke test for KWETU (demo mode).

Run:  python3 tests/browser/smoke.py
Optional env:  CHROME=/path/to/chrome   SHOTS=/dir/for/screenshots
Needs: python3 with playwright, and a Chrome/Chromium binary.
"""
import functools, http.server, os, re, shutil, socketserver, sys, threading
from datetime import date
from playwright.sync_api import sync_playwright, expect

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SHOTS = os.environ.get("SHOTS")
CHROME = os.environ.get("CHROME") or shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")
if SHOTS:
    os.makedirs(SHOTS, exist_ok=True)


# The shipped config points at real Supabase. This test runs the app in demo mode, so serve a demo config instead.
DEMO_CONFIG = ("window.KWETU_CONFIG={appName:'KWETU',supabaseUrl:'',supabaseAnonKey:'',defaultTownSlug:'bungoma',"
               "currency:{code:'KES',label:'KSh'},phoneCountryCode:'+254',minAge:18,paymentMode:'sandbox'};")
def force_demo(context):
    context.route("**/js/config.js", lambda r: r.fulfill(body=DEMO_CONFIG, content_type="application/javascript"))


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


httpd = socketserver.TCPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=ROOT))
BASE = f"http://127.0.0.1:{httpd.server_address[1]}"
threading.Thread(target=httpd.serve_forever, daemon=True).start()

passed = 0
def ok(name):
    global passed
    passed += 1
    print("  ok ", name)

def shot(page, name, full=False):
    if SHOTS:
        page.screenshot(path=os.path.join(SHOTS, name + ".png"), full_page=full)

def years_ago(n):
    t = date.today()
    return t.replace(year=t.year - n, day=min(t.day, 28)).isoformat()


with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=CHROME, args=["--no-sandbox"])
    ctx = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2)
    force_demo(ctx)
    page = ctx.new_page()
    problems = []
    page.on("pageerror", lambda e: problems.append("pageerror: " + str(e)))
    page.on("console", lambda m: problems.append("console: " + m.text) if m.type == "error" else None)
    page.on("requestfailed", lambda r: problems.append("requestfailed: " + r.url))

    # ---- Splash -> landing ----
    page.goto(BASE + "/index.html")
    expect(page.locator("#splash")).to_be_visible()
    expect(page.locator(".splash .tagline")).to_have_text("Your city, your people, your plans.")
    expect(page.locator("#splash .skyline rect").first).to_be_attached()
    shot(page, "01-splash")
    page.locator("#splash").click()
    expect(page.locator("#splash")).to_have_count(0)
    expect(page.locator(".hero h1")).to_be_visible()
    shot(page, "02-landing", full=True)
    ok("splash shows, tap enters landing")
    page.goto(BASE + "/index.html")
    expect(page.locator("#splash")).to_have_count(0)
    ok("splash is skipped on return visit in the same session")

    # ---- Guest browsing ----
    page.goto(BASE + "/home.html")
    expect(page.locator(".bottom-nav a, .bottom-nav button")).to_have_count(5)
    expect(page.locator("h1.page-title")).to_have_text("Welcome")
    expect(page.locator("#town-name")).to_have_text("Bungoma")
    expect(page.locator(".cat")).to_have_count(6)
    shot(page, "03-home-guest", full=True)
    page.locator("#nav-create").click()
    expect(page.get_by_role("dialog")).to_be_visible()
    expect(page.locator(".sheet .list-item")).to_have_count(5)
    expect(page.locator(".sheet .notice")).to_contain_text("Log in")
    shot(page, "04-create-sheet")
    page.keyboard.press("Escape")
    expect(page.get_by_role("dialog")).to_have_count(0)
    ok("home loads for guests; Create menu opens and closes")

    page.locator("#town-btn").click()
    page.locator('[data-slug="kisumu"]').click()
    expect(page.locator("#town-name")).to_have_text("Kisumu")
    expect(page.locator(".page-sub")).to_contain_text("Kisumu")
    page.locator("#town-btn").click()
    page.locator('[data-slug="bungoma"]').click()
    expect(page.locator("#town-name")).to_have_text("Bungoma")
    ok("town selector changes the town everywhere and persists")

    page.locator("#home-q").fill("karaoke")
    page.locator("#home-q").press("Enter")
    expect(page).to_have_url(re.compile(r"explore\.html\?q=karaoke"))
    expect(page.locator("h1.page-title")).to_contain_text("Explore")
    page.locator('[data-cat="events"]').click()
    expect(page.locator('[data-cat="events"]')).to_have_attribute("aria-pressed", "true")
    page.locator('[data-cat="companionship"]').click()
    expect(page.locator(".notice.warn")).to_contain_text("Adults only")
    shot(page, "05-explore")
    ok("search and category filters work; adult category shows its safety note")

    page.goto(BASE + "/activity.html")
    expect(page).to_have_url(re.compile(r"login\.html\?next=activity\.html"))
    ok("protected pages send guests to login and remember where they were going")

    # ---- Registration validation ----
    page.goto(BASE + "/register.html")
    page.locator("#register-form button[type=submit]").click()
    assert page.locator(".field-error").count() >= 6, "expected validation errors"
    expect(page.locator("#displayName")).to_be_focused()
    page.fill("#displayName", "Kid Tester"); page.fill("#email", "kid@example.com"); page.fill("#phone", "0712345678")
    page.fill("#dob", years_ago(17)); page.fill("#password", "abcdefg1"); page.fill("#confirm", "abcdefg1"); page.check("#agree")
    page.locator("#register-form button[type=submit]").click()
    expect(page.locator("#dob").locator("xpath=..").locator(".field-error")).to_contain_text("18")
    expect(page).to_have_url(re.compile(r"register\.html"))
    shot(page, "06-register-errors", full=True)
    ok("registration validates every field and blocks under-18s")

    # ---- Successful registration ----
    page.fill("#displayName", "Amina Wekesa"); page.fill("#email", "amina@example.com"); page.fill("#phone", "0712 345 678")
    page.fill("#dob", "1999-04-12")
    page.select_option("#town", "kakamega")
    page.locator("#register-form button[type=submit]").click()
    expect(page).to_have_url(re.compile(r"home\.html"))
    expect(page.locator("h1.page-title")).to_contain_text("Hi Amina")
    expect(page.locator("#town-name")).to_have_text("Kakamega")
    expect(page.locator(".demo-chip")).to_be_visible()
    shot(page, "07-home-signed-in", full=True)
    ok("registration signs you in, lands on a personalised home, picks your town")

    # ---- Signed-in pages ----
    page.goto(BASE + "/activity.html")
    expect(page.locator(".empty h3")).to_have_text("You are all caught up")
    page.goto(BASE + "/profile.html")
    expect(page.locator("h1.page-title")).to_have_text("Amina Wekesa")
    expect(page.locator(".badge", has_text="Active")).to_have_count(1)
    expect(page.locator(".notice.warn")).to_contain_text("Demo mode")
    shot(page, "08-profile", full=True)
    page.fill("#pf-name", "Amina W.")
    page.fill("#pf-bio", "Love live music <b>nights</b>")
    page.locator("#profile-form button[type=submit]").click()
    expect(page.locator(".toast")).to_contain_text("Profile saved")
    page.reload()
    expect(page.locator("h1.page-title")).to_have_text("Amina W.")
    expect(page.locator("#pf-bio")).to_have_value("Love live music <b>nights</b>")
    assert page.locator("#app b").count() == 0, "bio HTML must be escaped"
    page.fill("#pf-name", "A")
    page.locator("#profile-form button[type=submit]").click()
    expect(page.locator("#profile-form .field-error")).to_be_visible()
    ok("profile edits persist, user text is escaped, validation shows errors")

    page.locator("#nav-create").click()
    expect(page.locator(".sheet .notice")).to_have_count(0)
    page.locator(".sheet .list-item").first.click()
    expect(page.locator(".toast").last).to_contain_text("arrives in an upcoming block")
    ok("signed-in Create menu is honest about features that are not built yet")

    # ---- Log out / log in ----
    page.locator("#signout").click()
    expect(page.locator(".hero h1")).to_be_visible()
    page.goto(BASE + "/login.html")
    page.fill("#email", "amina@example.com"); page.fill("#password", "wrongpass1")
    page.locator("#login-form button[type=submit]").click()
    expect(page.locator(".form-error")).to_contain_text("Incorrect email or password")
    page.fill("#password", "abcdefg1")
    page.locator("#login-form button[type=submit]").click()
    expect(page).to_have_url(re.compile(r"home\.html"))
    ok("logout, wrong password rejected, login works")

    # ---- Redirect safety ----
    expect(page.locator(".bottom-nav")).to_be_visible()  # wait until the new page has fully booted
    page.evaluate("KWETU.data.signOut()")
    page.goto(BASE + "/login.html?next=https://evil.example/")
    page.fill("#email", "amina@example.com"); page.fill("#password", "abcdefg1")
    page.locator("#login-form button[type=submit]").click()
    expect(page).to_have_url(re.compile(re.escape(BASE) + r"/home\.html"))
    ok("login ignores off-site redirect targets")

    # ---- Legal pages ----
    for name in ("terms", "privacy", "guidelines"):
        page.goto(f"{BASE}/{name}.html")
        expect(page.locator(".banner")).to_contain_text("Draft placeholder")
    ok("legal pages exist and are clearly marked as drafts")

    # ---- Desktop layout ----
    desk = browser.new_context(viewport={"width": 1280, "height": 800})
    force_demo(desk)
    d = desk.new_page()
    d.on("pageerror", lambda e: problems.append("pageerror(desktop): " + str(e)))
    d.goto(BASE + "/home.html")
    box = d.locator(".bottom-nav").bounding_box()
    assert box["x"] < 5 and box["width"] < 120 and box["height"] > 700, f"nav should be a left rail, got {box}"
    shot(d, "09-home-desktop")
    d.goto(BASE + "/index.html")
    d.locator("#splash").click()
    expect(d.locator(".hero h1")).to_be_visible()
    shot(d, "10-landing-desktop")
    ok("desktop layout turns the bottom bar into a side rail")

    browser.close()

httpd.shutdown()
if problems:
    print("\nBROWSER PROBLEMS:")
    for x in problems:
        print(" -", x)
    sys.exit(1)
print(f"\n{passed} browser checks passed, no console errors")
