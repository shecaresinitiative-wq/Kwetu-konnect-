-- Tests for migration 0001 (foundation). Run via tests/run_db_tests.sh.
\set ON_ERROR_STOP on
\echo '== seed =='
select public.tap_expect_value('select count(*) from public.towns', '8');
select public.tap_expect_value('select slug from public.towns where is_default', 'bungoma');
select public.tap_expect_error($$insert into public.towns(slug,name,is_default) values ('second-default','X',true)$$, 'towns_single_default');

\echo '== age gate (server side) =='
select public.tap_expect_error(
  $$insert into auth.users(email, raw_user_meta_data) values ('kid@example.com', '{"display_name":"Kid","date_of_birth":"2015-05-05"}')$$, '18 or older');
select public.tap_expect_error(
  $$insert into auth.users(email, raw_user_meta_data) values ('nodob@example.com', '{"display_name":"NoDob"}')$$, '18 or older');
select public.tap_expect_error(
  format($$insert into auth.users(email, raw_user_meta_data) values ('almost@example.com', '{"display_name":"Almost","date_of_birth":"%s"}')$$, (current_date - interval '18 years' + interval '1 day')::date), '18 or older');
select public.tap_expect_value(
  format($$insert into auth.users(email, raw_user_meta_data) values ('exact18@example.com', '{"display_name":"Exact","date_of_birth":"%s"}') returning email$$, (current_date - interval '18 years')::date), 'exact18@example.com');

\echo '== sign-up creates profile, private data and base role =='
select gen_random_uuid() as ua, gen_random_uuid() as ub, gen_random_uuid() as uc \gset
insert into auth.users(id, email, raw_user_meta_data) values
  (:'ua', 'alice@example.com', '{"display_name":"Alice Test","date_of_birth":"2000-01-01","phone":"+254712345678","town_slug":"kisumu"}'),
  (:'ub', 'bob@example.com',   '{"display_name":"Bob Test","date_of_birth":"1995-06-15","phone":"0712","town_slug":"does-not-exist"}'),
  (:'uc', 'carol@example.com', '{"display_name":"Carol Admin","date_of_birth":"1990-01-01","phone":"+254733000111"}');
select public.tap_expect_value($$select t.slug from public.profiles p join public.towns t on t.id = p.town_id where p.display_name = 'Alice Test'$$, 'kisumu');
select public.tap_expect_value($$select t.slug from public.profiles p join public.towns t on t.id = p.town_id where p.display_name = 'Bob Test'$$, 'bungoma');
select public.tap_expect_value($$select coalesce(phone_e164, 'NULL') from public.profile_private pp join public.profiles p on p.id = pp.user_id where p.display_name = 'Bob Test'$$, 'NULL');
select public.tap_expect_value($$select count(*) from public.user_roles where role = 'user' and status = 'active'$$, '4');
select public.tap_expect_error(
  $$insert into auth.users(email, raw_user_meta_data) values ('dupe@example.com', '{"display_name":"Dupe","date_of_birth":"1990-01-01","phone":"+254712345678"}')$$, 'duplicate key');

\echo '== RLS as a normal signed-in user (Alice) =='
begin;
set local role authenticated;
select set_config('request.jwt.claim.sub', :'ua', true);
select public.tap_expect_value('select count(*) from public.profile_private', '1');
select public.tap_expect_value('select count(*) from public.user_roles', '1');
select public.tap_expect_value('select count(*) from public.profiles', '4');
select public.tap_expect_value($$with u as (update public.profiles set bio = 'hello' where id = auth.uid() returning 1) select count(*) from u$$, '1');
select public.tap_expect_value(format($$with u as (update public.profiles set bio = 'hacked' where id = %L returning 1) select count(*) from u$$, :'ub'), '0');
select public.tap_expect_error($$update public.profiles set status = 'suspended' where id = auth.uid()$$, 'administrator');
select public.tap_expect_error($$update public.profile_private set date_of_birth = '1980-01-01' where user_id = auth.uid()$$, 'cannot be changed');
select public.tap_expect_error($$update public.profile_private set phone_verified_at = now() where user_id = auth.uid()$$, 'backend');
select public.tap_expect_error($$insert into public.user_roles(user_id, role, status) values (auth.uid(), 'admin', 'active')$$, 'permission denied');
select public.tap_expect_error($$update public.user_roles set role = 'admin' where user_id = auth.uid()$$, 'permission denied');
select public.tap_expect_error($$delete from public.profiles where id = auth.uid()$$, 'permission denied');
select public.tap_expect_error($$insert into public.audit_logs(action) values ('forged')$$, 'permission denied');
select public.tap_expect_value('select count(*) from public.audit_logs', '0');
select public.tap_expect_value($$with u as (update public.towns set name = 'Hacked' where slug = 'bungoma' returning 1) select count(*) from u$$, '0');
commit;

\echo '== RLS as a guest (anon) =='
begin;
set local role anon;
select public.tap_expect_value('select count(*) from public.towns', '8');
select public.tap_expect_error('select * from public.profiles', 'permission denied');
select public.tap_expect_error('select * from public.profile_private', 'permission denied');
select public.tap_expect_error('select * from public.user_roles', 'permission denied');
commit;

\echo '== admin: granted by the backend, then verified =='
insert into public.user_roles(user_id, role, status) values (:'uc', 'admin', 'active');
begin;
set local role authenticated;
select set_config('request.jwt.claim.sub', :'uc', true);
select public.tap_expect_value('select count(*) from public.profile_private', '4');
select public.tap_expect_value('select (count(*) >= 5)::text from public.audit_logs', 'true');
select public.tap_expect_value(format($$with u as (update public.profiles set status = 'suspended' where id = %L returning 1) select count(*) from u$$, :'ua'), '1');
commit;

\echo '== suspended accounts disappear from other people, not from themselves =='
begin;
set local role authenticated;
select set_config('request.jwt.claim.sub', :'ub', true);
select public.tap_expect_value(format('select count(*) from public.profiles where id = %L', :'ua'), '0');
commit;
begin;
set local role authenticated;
select set_config('request.jwt.claim.sub', :'ua', true);
select public.tap_expect_value('select count(*) from public.profiles where id = auth.uid()', '1');
commit;

\echo '== deleting a user cascades cleanly (and the audit trigger handles DELETE) =='
delete from auth.users where id = :'ub';
select public.tap_expect_value(format('select count(*) from public.profiles where id = %L', :'ub'), '0');

\echo 'ALL DB TESTS PASSED'
