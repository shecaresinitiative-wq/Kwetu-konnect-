-- Tests for migration 0002 (function privileges). Run via tests/run_db_tests.sh.
\set ON_ERROR_STOP on
\echo '== internal functions are not callable by visitors or members, but RLS still works =='

begin;
set local role anon;
select public.tap_expect_value('select public.is_admin()::text', 'false');
select public.tap_expect_value('select count(*) from public.towns', '8');
select public.tap_expect_error($$select public.has_role('admin')$$, 'permission denied');
select public.tap_expect_error('select public.handle_new_user()', 'permission denied');
select public.tap_expect_error('select public.log_role_change()', 'permission denied');
select public.tap_expect_error('select public.protect_profile_status()', 'permission denied');
select public.tap_expect_error('select public.protect_private_columns()', 'permission denied');
commit;

begin;
set local role authenticated;
select public.tap_expect_value('select public.is_admin()::text', 'false');
select public.tap_expect_error($$select public.has_role('admin')$$, 'permission denied');
select public.tap_expect_error('select public.handle_new_user()', 'permission denied');
commit;

\echo '== triggers still fire after the revoke (sign-up still creates a profile) =='
select gen_random_uuid() as uz \gset
insert into auth.users(id, email, raw_user_meta_data)
  values (:'uz', 'zed@example.com', '{"display_name":"Zed Test","date_of_birth":"1992-02-02"}');
select public.tap_expect_value(format('select count(*) from public.profiles where id = %L', :'uz'), '1');
select public.tap_expect_value(format($$select count(*) from public.user_roles where user_id = %L and role = 'user'$$, :'uz'), '1');
delete from auth.users where id = :'uz';

\echo 'ALL FUNCTION-PRIVILEGE TESTS PASSED'
