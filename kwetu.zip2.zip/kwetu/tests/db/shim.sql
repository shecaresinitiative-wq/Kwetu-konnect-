-- Minimal stand-in for the parts of Supabase that migrations depend on, so migrations can be
-- tested on a plain local Postgres. NOT for production: Supabase provides all of this itself.
-- Roles are cluster-wide, so create them only if a previous run has not already.
do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'anon') then create role anon nologin; end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then create role authenticated nologin; end if;
  if not exists (select 1 from pg_roles where rolname = 'service_role') then create role service_role nologin bypassrls; end if;
end $$;

create schema auth;
create table auth.users (
  id uuid primary key default gen_random_uuid(),
  email text,
  raw_user_meta_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create function auth.uid() returns uuid language sql stable as
$$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;

grant usage on schema public, auth to anon, authenticated, service_role;
alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
alter default privileges in schema public grant all on sequences to anon, authenticated, service_role;

-- Test helpers (run as whichever role the test switches to)
create function public.tap_expect_error(q text, pat text) returns void language plpgsql as $$
begin
  begin
    execute q;
  exception when others then
    if sqlerrm ilike '%' || pat || '%' then return; end if;
    raise exception 'TEST FAILED: raised [%] but expected pattern [%] for: %', sqlerrm, pat, q;
  end;
  raise exception 'TEST FAILED: expected error matching [%] but succeeded: %', pat, q;
end $$;

create function public.tap_expect_value(q text, expected text) returns void language plpgsql as $$
declare v text;
begin
  execute q into v;
  if v is distinct from expected then
    raise exception 'TEST FAILED: [%] returned [%], expected [%]', q, v, expected;
  end if;
end $$;
