// Unit tests for validation and the demo data layer. Run: node tests/js/core.test.js
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Minimal browser stand-ins (no DOM needed for these modules).
const mem = {};
global.window = global;
global.localStorage = {
  getItem: (k) => (k in mem ? mem[k] : null),
  setItem: (k, v) => { mem[k] = String(v); },
  removeItem: (k) => { delete mem[k]; }
};
const root = path.join(__dirname, '..', '..');
for (const f of ['js/config.js', 'js/core.js', 'js/categories.js', 'js/data.js']) {
  vm.runInThisContext(fs.readFileSync(path.join(root, f), 'utf8'), { filename: f });
  // The real config points at Supabase; these tests exercise the demo adapter, so force demo mode.
  if (f === 'js/config.js') { global.KWETU_CONFIG.supabaseUrl = ''; global.KWETU_CONFIG.supabaseAnonKey = ''; }
}
const K = global.KWETU;
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('  ok  ' + name); };

(async () => {
  console.log('validation');
  await t('Kenyan phone numbers normalise to +254', () => {
    for (const ok of ['0712345678', '0712 345 678', '+254712345678', '254712345678', '712345678', '0112345678', '0712-345-678'])
      assert.match(K.validate.phone(ok), /^\+254[17]\d{8}$/, ok);
    assert.equal(K.validate.phone('0712345678'), '+254712345678');
    assert.equal(K.validate.phone('0112345678'), '+254112345678');
  });
  await t('bad phone numbers are rejected', () => {
    for (const bad of ['', '0712', '071234567890', '0212345678', '+255712345678', 'abc', '07123456789'])
      assert.equal(K.validate.phone(bad), null, bad);
  });
  await t('age calculation, including birthday edges', () => {
    const now = new Date(Date.UTC(2026, 10, 9)); // 9 Nov 2026
    assert.equal(K.validate.age('2008-11-09', now), 18);
    assert.equal(K.validate.age('2008-11-10', now), 17);
    assert.equal(K.validate.age('2000-02-29', now), 26);
    assert.equal(K.validate.age('2001-02-29', now), null); // not a real date
    assert.equal(K.validate.age('not-a-date', now), null);
    assert.equal(K.validate.age('', now), null);
  });
  await t('email, password and name rules', () => {
    assert.ok(K.validate.email('a@b.co'));
    assert.ok(!K.validate.email('a@b'));
    assert.ok(!K.validate.email('a b@c.com'));
    assert.ok(K.validate.password('abcdefg1'));
    assert.ok(!K.validate.password('abcdefgh'));
    assert.ok(!K.validate.password('12345678'));
    assert.ok(!K.validate.password('a1'));
    assert.ok(K.validate.displayName('Jo'));
    assert.ok(!K.validate.displayName(' J '));
    assert.ok(!K.validate.displayName('x'.repeat(61)));
  });
  await t('safeNext blocks open redirects', () => {
    assert.equal(K.safeNext('profile.html'), 'profile.html');
    assert.equal(K.safeNext('explore.html?cat=events'), 'explore.html?cat=events');
    for (const bad of ['https://evil.com', '//evil.com', 'javascript:alert(1)', '../x.html', 'a/b.html', ''])
      assert.equal(K.safeNext(bad), 'home.html', bad);
  });
  await t('escaping', () => assert.equal(K.esc('<a href="x">&\'</a>'), '&lt;a href=&quot;x&quot;&gt;&amp;&#39;&lt;/a&gt;'));

  console.log('config and categories');
  await t('demo mode is on when no Supabase keys are set', () => assert.equal(K.isDemo(), true));
  await t('default town exists and nothing hardcodes it', () => {
    assert.ok(K.data.staticTowns.some((x) => x.slug === K.config.defaultTownSlug));
    assert.ok(K.data.staticTowns.length > 1);
  });
  await t('categories are unique and complete', () => {
    const slugs = K.categories.map((c) => c.slug);
    assert.equal(new Set(slugs).size, slugs.length);
    assert.deepEqual(slugs.sort(), ['businesses', 'companionship', 'events', 'experiences', 'transport', 'wellness']);
    assert.ok(K.categoryBySlug('companionship').adultsOnly);
  });

  console.log('demo data layer');
  const good = { displayName: 'Amina Wekesa', email: 'Amina@Example.com', phone: '+254712345678', dob: '1998-03-02', townSlug: 'bungoma', password: 'passw0rdok' };
  await t('no session before sign up', async () => assert.equal(await K.data.getSession(), null));
  await t('under-18 sign up is refused', async () => {
    await assert.rejects(K.data.signUp({ ...good, dob: '2020-01-01' }), /18 or older/);
    assert.equal((await K.data.getSession()), null);
  });
  await t('sign up creates a session and a member profile', async () => {
    const r = await K.data.signUp(good);
    assert.equal(r.needsConfirmation, false);
    const s = await K.data.getSession();
    assert.equal(s.user.email, 'amina@example.com');
    const p = await K.data.getProfile();
    assert.equal(p.displayName, 'Amina Wekesa');
    assert.equal(p.townName, 'Bungoma');
    assert.deepEqual(p.roles, [{ role: 'user', status: 'active' }]);
    assert.equal(p.demo, true);
  });
  await t('passwords are not stored in plain text', () => {
    assert.ok(!JSON.stringify(mem).includes('passw0rdok'));
  });
  await t('duplicate email and phone are refused', async () => {
    await assert.rejects(K.data.signUp({ ...good, phone: '+254733000999' }), /email already exists/);
    await assert.rejects(K.data.signUp({ ...good, email: 'other@example.com' }), /phone number already exists/);
  });
  await t('profile update persists and validates the town', async () => {
    const p = await K.data.updateProfile({ displayName: 'Amina W.', bio: ' Hello ', townSlug: 'kisumu' });
    assert.equal(p.displayName, 'Amina W.');
    assert.equal(p.bio, 'Hello');
    assert.equal(p.townName, 'Kisumu');
    await assert.rejects(K.data.updateProfile({ displayName: 'X Y', bio: '', townSlug: 'atlantis' }), /valid town/);
  });
  await t('sign out, wrong password, then sign in', async () => {
    await K.data.signOut();
    assert.equal(await K.data.getSession(), null);
    assert.equal(await K.data.getProfile(), null);
    await assert.rejects(K.data.signIn({ email: 'amina@example.com', password: 'nope' }), /Incorrect email or password/);
    await K.data.signIn({ email: 'AMINA@example.com', password: 'passw0rdok' });
    assert.equal((await K.data.getSession()).user.email, 'amina@example.com');
  });

  console.log('\n' + n + ' JS tests passed');
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
