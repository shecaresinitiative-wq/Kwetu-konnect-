// Site integrity: every page's local links, scripts and styles exist; every page boots a registered page module;
// every JS file parses. Run: node tests/js/site.test.js
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..', '..');
const htmlFiles = fs.readdirSync(root).filter((f) => f.endsWith('.html'));
const problems = [];
let checks = 0;

// 1. Every JS file parses.
function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
    e.isDirectory() ? (['node_modules', '.git'].includes(e.name) ? [] : walk(path.join(dir, e.name))) : [path.join(dir, e.name)]);
}
for (const f of walk(root).filter((x) => x.endsWith('.js'))) {
  checks++;
  try { new vm.Script(fs.readFileSync(f, 'utf8'), { filename: f }); } catch (e) { problems.push(`syntax error in ${path.relative(root, f)}: ${e.message}`); }
}

// 2. Every html page: assets exist, links resolve, ids referenced by scripts are unique.
const pageModules = {};
for (const f of fs.readdirSync(path.join(root, 'js', 'pages'))) {
  const src = fs.readFileSync(path.join(root, 'js', 'pages', f), 'utf8');
  for (const m of src.matchAll(/K\.pages\.(\w+)\s*=/g)) pageModules[m[1]] = f;
}
for (const file of htmlFiles) {
  const html = fs.readFileSync(path.join(root, file), 'utf8');
  for (const m of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const ref = m[1];
    if (/^(https?:|mailto:|tel:|#|javascript:)/.test(ref)) continue;
    const clean = ref.split('#')[0].split('?')[0];
    checks++;
    if (clean && !fs.existsSync(path.join(root, clean))) problems.push(`${file}: broken reference "${ref}"`);
  }
  const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]);
  const dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  checks++;
  if (dup.length) problems.push(`${file}: duplicate ids ${[...new Set(dup)].join(', ')}`);

  const page = /data-page="([^"]+)"/.exec(html);
  if (page) {
    checks++;
    if (!pageModules[page[1]]) problems.push(`${file}: data-page="${page[1]}" has no KWETU.pages.${page[1]} module`);
    else if (!html.includes('js/pages/' + pageModules[page[1]])) problems.push(`${file}: does not include js/pages/${pageModules[page[1]]}`);
    for (const need of ['js/config.js', 'js/core.js', 'js/data.js', 'js/shell.js']) {
      checks++;
      if (!html.includes(need)) problems.push(`${file}: missing ${need}`);
    }
    // Scripts must load in dependency order.
    const order = [...html.matchAll(/<script src="([^"]+)"/g)].map((m) => m[1]);
    const idx = (s) => order.indexOf(s);
    checks++;
    if (!(idx('js/config.js') < idx('js/core.js') && idx('js/core.js') < idx('js/data.js') && idx('js/data.js') < idx('js/shell.js'))) problems.push(`${file}: scripts out of order`);
  }
  if (/data-app-shell/.test(html)) {
    checks++;
    if (!html.includes('id="app"')) problems.push(`${file}: app-shell page needs <main id="app">`);
    if (!html.includes('js/categories.js')) problems.push(`${file}: app-shell page needs js/categories.js`);
  }
}

// 3. Every nav destination exists, and no secrets are in committed files.
const shell = fs.readFileSync(path.join(root, 'js', 'shell.js'), 'utf8');
for (const m of shell.matchAll(/href: '([^']+)'/g)) { checks++; if (!fs.existsSync(path.join(root, m[1]))) problems.push(`nav target missing: ${m[1]}`); }
for (const f of walk(root).filter((x) => /\.(js|html|sql|md)$/.test(x) && !x.includes(path.sep + 'tests' + path.sep))) {
  const s = fs.readFileSync(f, 'utf8');
  checks++;
  if (/service_role\s*[:=]\s*['"]ey/i.test(s) || /eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}/.test(s)) problems.push(`possible secret key in ${path.relative(root, f)}`);
}

if (problems.length) { console.error(problems.map((p) => ' - ' + p).join('\n')); console.error(`\n${problems.length} problem(s)`); process.exit(1); }
console.log(`site integrity ok (${checks} checks, ${htmlFiles.length} pages)`);
assert.ok(htmlFiles.length >= 9);
