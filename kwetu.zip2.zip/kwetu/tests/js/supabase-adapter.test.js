// Tests the Supabase adapter's logic against a FAKE supabase-js client (no network).
// This proves the adapter sends the right data and maps results and errors correctly.
// It does not replace one real sign-up against your live project. Run: node tests/js/supabase-adapter.test.js
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

global.window = global;
global.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
global.KWETU_CONFIG = { supabaseUrl: 'https://example.supabase.co', supabaseAnonKey: 'sb_publishable_test', defaultTownSlug: 'bungoma', minAge: 18 };

const calls = [];            // every query-builder call, in order
let results = {};            // table:mode -> {data,error}
let authFake = {};

function builder(table) {
  const state = { mode: 'list' };
  const b = {};
  for (const m of ['select', 'eq', 'order', 'update', 'insert', 'single', 'maybeSingle']) {
    b[m] = (...args) => {
      calls.push([table, m, ...args]);
      if (m === 'single') state.mode = 'single';
      if (m === 'maybeSingle') state.mode = 'maybe';
      if (m === 'update') state.mode = 'update';
      return b;
    };
  }
  b.then = (res, rej) => Promise.resolve(results[table + ':' + state.mode] || { data: null, error: null }).then(res, rej);
  return b;
}
// The adapter keeps one client for its lifetime, so `auth` must follow whichever fake each test installs.
const authProxy = new Proxy({}, { get: (_, key) => authFake[key] });
global.supabase = { createClient: () => ({ from: builder, auth: authProxy }) };

const root = path.join(__dirname, '..', '..');
for (const f of ['js/core.js', 'js/categories.js', 'js/data.js']) vm.runInThisContext(fs.readFileSync(path.join(root, f), 'utf8'), { filename: f });
const K = global.KWETU;
let n = 0;
const t = async (name, fn) => { calls.length = 0; await fn(); n++; console.log('  ok  ' + name); };

(async () => {
  assert.equal(K.isDemo(), false);
  await K.data.init();

  await t('sign up sends the profile fields as metadata the database trigger reads', async () => {
    let sent;
    authFake = { signUp: async (arg) => { sent = arg; return { data: { user: { id: 'u1' }, session: null }, error: null }; } };
    const r = await K.data.signUp({ displayName: ' Amina ', email: ' a@b.co ', phone: '+254712345678', dob: '1999-04-12', townSlug: 'kisumu', password: 'abcdefg1' });
    assert.deepEqual(sent, { email: 'a@b.co', password: 'abcdefg1', options: { data: { display_name: 'Amina', phone: '+254712345678', date_of_birth: '1999-04-12', town_slug: 'kisumu' } } });
    assert.equal(r.needsConfirmation, true);
    authFake = { signUp: async () => ({ data: { user: { id: 'u1' }, session: { access_token: 'x' } }, error: null }) };
    assert.equal((await K.data.signUp({ displayName: 'Am', email: 'a@b.co', phone: '+254712345678', dob: '1999-04-12', townSlug: 'kisumu', password: 'abcdefg1' })).needsConfirmation, false);
  });

  await t('Supabase errors become friendly messages', async () => {
    const form = { displayName: 'Am', email: 'a@b.co', phone: '+254712345678', dob: '1999-04-12', townSlug: 'kisumu', password: 'abcdefg1' };
    authFake = { signUp: async () => ({ data: {}, error: { message: 'User already registered' } }) };
    await assert.rejects(K.data.signUp(form), /already exists/);
    authFake = { signUp: async () => ({ data: {}, error: { message: 'Database error saving new user' } }) };
    await assert.rejects(K.data.signUp(form), /18 or older/);
    authFake = { signInWithPassword: async () => ({ data: {}, error: { message: 'Invalid login credentials' } }) };
    await assert.rejects(K.data.signIn({ email: 'a@b.co', password: 'x' }), /Incorrect email or password/);
    authFake = { signInWithPassword: async () => ({ data: {}, error: { message: 'Email not confirmed' } }) };
    await assert.rejects(K.data.signIn({ email: 'a@b.co', password: 'x' }), /confirm your email/);
  });

  await t('session maps to id + email, and is null when signed out', async () => {
    authFake = { getSession: async () => ({ data: { session: { user: { id: 'u1', email: 'a@b.co' } } } }) };
    assert.deepEqual(await K.data.getSession(), { user: { id: 'u1', email: 'a@b.co' } });
    authFake = { getSession: async () => ({ data: { session: null } }) };
    assert.equal(await K.data.getSession(), null);
  });

  await t('towns load from the database, and fall back to built-in towns if the request fails', async () => {
    results = { 'towns:list': { data: [{ slug: 'kisumu', name: 'Kisumu', county: 'Kisumu', latitude: -0.09, longitude: 34.76 }], error: null } };
    assert.deepEqual(await K.data.listTowns(), [{ slug: 'kisumu', name: 'Kisumu', county: 'Kisumu', lat: -0.09, lng: 34.76 }]);
    assert.deepEqual(calls.filter((c) => c[1] === 'eq')[0], ['towns', 'eq', 'is_active', true]);
    results = { 'towns:list': { data: null, error: { message: 'boom' } } };
    assert.ok((await K.data.listTowns()).some((x) => x.slug === 'bungoma'));
  });

  await t('profile combines profiles + profile_private + user_roles', async () => {
    authFake = { getUser: async () => ({ data: { user: { id: 'u1', email: 'a@b.co' } } }) };
    results = {
      'profiles:single': { data: { id: 'u1', display_name: 'Amina', bio: null, created_at: '2026-11-09T00:00:00Z', towns: { slug: 'kisumu', name: 'Kisumu' } }, error: null },
      'profile_private:maybe': { data: { phone_e164: '+254712345678', date_of_birth: '1999-04-12' }, error: null },
      'user_roles:list': { data: [{ role: 'user', status: 'active' }], error: null }
    };
    const p = await K.data.getProfile();
    assert.deepEqual(p, { id: 'u1', email: 'a@b.co', displayName: 'Amina', bio: '', townSlug: 'kisumu', townName: 'Kisumu', phone: '+254712345678', dob: '1999-04-12', roles: [{ role: 'user', status: 'active' }], createdAt: '2026-11-09T00:00:00Z', demo: false });
    assert.ok(calls.some((c) => c[0] === 'profiles' && c[1] === 'select' && /towns\(slug,name\)/.test(c[2])));
  });

  await t('profile update writes only the editable columns, by town id', async () => {
    authFake = { getUser: async () => ({ data: { user: { id: 'u1', email: 'a@b.co' } } }) };
    results = {
      'towns:single': { data: { id: 'town-uuid' }, error: null },
      'profiles:update': { data: null, error: null },
      'profiles:single': { data: { id: 'u1', display_name: 'New', bio: 'Hi', created_at: 'x', towns: { slug: 'kisumu', name: 'Kisumu' } }, error: null },
      'profile_private:maybe': { data: {}, error: null }, 'user_roles:list': { data: [], error: null }
    };
    const p = await K.data.updateProfile({ displayName: ' New ', bio: ' Hi ', townSlug: 'kisumu' });
    assert.equal(p.displayName, 'New');
    const upd = calls.find((c) => c[0] === 'profiles' && c[1] === 'update');
    assert.deepEqual(upd[2], { display_name: 'New', bio: 'Hi', town_id: 'town-uuid' });
    results['towns:single'] = { data: null, error: { message: 'none' } };
    await assert.rejects(K.data.updateProfile({ displayName: 'New', bio: '', townSlug: 'atlantis' }), /valid town/);
  });

  console.log('\n' + n + ' Supabase adapter tests passed');
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });
