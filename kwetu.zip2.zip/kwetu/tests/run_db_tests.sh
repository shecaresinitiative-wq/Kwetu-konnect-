#!/usr/bin/env bash
# Runs every migration plus seed.sql on a throwaway local Postgres and checks the security rules.
# Usage:  PGHOST=<host or socket dir> PGUSER=<superuser> ./tests/run_db_tests.sh
# It creates (and drops) a database called kwetu_test. It never touches Supabase.
set -euo pipefail
cd "$(dirname "$0")/db"
DB=kwetu_test
psql -d postgres -v ON_ERROR_STOP=1 -qc "drop database if exists $DB" -c "create database $DB"
psql -d "$DB" -v ON_ERROR_STOP=1 -q -f shim.sql
for f in ../../supabase/migrations/*.sql; do
  echo "-- applying $(basename "$f")"
  psql -d "$DB" -v ON_ERROR_STOP=1 -q -f "$f"
done
psql -d "$DB" -v ON_ERROR_STOP=1 -q -f ../../supabase/seed.sql
for t in *.test.sql; do
  echo "-- running $t"
  psql -d "$DB" -v ON_ERROR_STOP=1 -q -f "$t"
done
psql -d postgres -qc "drop database if exists $DB"
