# KWETU

> Your city, your people, your plans.

A mobile-first, location-driven platform that connects people, service providers, venues, event organisers and transport operators in their local town. Launch market: Bungoma, Kenya (configurable; nothing is hardcoded to one town).

The full product spec is in [`docs/PRD.md`](docs/PRD.md). The build is delivered in **blocks**, one at a time. See [`docs/BLOCKS.md`](docs/BLOCKS.md) for what each block added.

**Status:** Block 1 (Foundation). See [`CHECKLIST.md`](CHECKLIST.md) for exactly what works, what is simulated and what still needs credentials or legal review.

**Developers: start with [`docs/HANDOVER.md`](docs/HANDOVER.md).** It has the rules, the 10-block roadmap, the Block 2 brief and how to hand the work back.

## Run it (no install, no build)

Either:

- **Double-click `index.html`.** It works from the file system.
- Or serve the folder: `python3 -m http.server 8080` then open <http://localhost:8080>.

Out of the box it runs in **DEMO MODE**: accounts and data live only in your browser (marked with a purple DEMO chip). Never use a real password in demo mode.

## Supabase

**This zip is already connected** to the KWETU Supabase project (Frankfurt, ref `oujucwnvfpgndylucgjh`). Migrations 0001 and 0002 and the town seed are already applied there, and `js/config.js` holds its URL and public key, so the app runs in real mode (no DEMO chip).

One thing is left for you: in the Supabase dashboard open **Authentication > Providers > Email** and turn **Confirm email** off while testing. With it on, sign-up works but waits for an email, and Supabase's built-in email sender is heavily rate-limited.

To point at a different project (or set one up from scratch), follow these steps. To go back to demo mode, empty the two values in `js/config.js`.

1. Create a project at <https://supabase.com>.
2. In **SQL Editor**, run every file in `supabase/migrations/` in order (0001, then 0002), then `supabase/seed.sql`.
   (Or with the Supabase CLI: `supabase link` then `supabase db push`.)
3. In **Authentication > Providers > Email**, turn **Confirm email** off while testing (or leave it on; the app shows "check your email").
4. In **Project Settings > API**, copy the **Project URL** and the **anon / publishable key** into `js/config.js`.
5. Reload. The DEMO chip disappears and sign-up, login and profiles use the real database.

**Safe to commit:** the Project URL and the anon key (Row Level Security protects the data).
**Never commit:** the `service_role` key, M-Pesa secrets or any private credential. Those go in Supabase Edge Function secrets.

## Put it on GitHub

```bash
cd kwetu
git init -b main
git add .
git commit -m "KWETU Block 1: foundation"
git remote add origin https://github.com/<you>/<your-empty-repo>.git
git push -u origin main
```

To publish it as a site, GitHub Pages (Settings > Pages > Deploy from branch `main` / root) works as-is.

## Project layout

```
index.html               splash screen + landing page
login.html register.html sign-in and sign-up
home.html explore.html activity.html profile.html     the five-tab app
terms.html privacy.html guidelines.html               legal drafts (need legal review)

css/   tokens.css (design tokens) base.css app.css landing.css
js/    config.js   public settings; empty keys = demo mode
       core.js     helpers, validation (KE phone, 18+), icons, toasts, sheets
       data.js     the ONLY layer that talks to Supabase or localStorage
       shell.js    page boot, header, town selector, bottom nav, Create menu
       categories.js  the pillars as categories
       skyline.js  the night-city artwork
       pages/      one file per page: home, explore, activity, profile, auth, landing

supabase/migrations/     numbered SQL, applied in order, never edited after running
supabase/seed.sql        launch towns
tests/                   db (Postgres + RLS), js (unit + site integrity), browser (end to end)
docs/                    PRD, ARCHITECTURE, BLOCKS
```

## Adding to the project (the rules that keep it from being taken apart)

1. **New page:** add `name.html` (copy a sibling), add `js/pages/name.js` that sets `KWETU.pages.name = { init }`, add its nav link if needed.
2. **New data:** add a NEW migration file `supabase/migrations/<timestamp>_<what>.sql`. Never edit one that has already run.
3. **New data access:** add the method to **both** adapters in `js/data.js` (demo and Supabase). Pages never call Supabase directly.
4. **Anything sensitive** (payments, ticket issue and validation, role grants, commissions) is a Supabase Edge Function, never browser code.
5. Run the tests below before sending a block.

## Tests

```bash
node tests/js/core.test.js          # validation + demo data layer
node tests/js/supabase-adapter.test.js   # Supabase adapter logic against a fake client (no network)
node tests/js/site.test.js          # every link, script and page module resolves; no secrets committed
python3 tests/browser/smoke.py      # real browser, end to end (needs playwright + Chrome)
PGHOST=... PGUSER=... ./tests/run_db_tests.sh   # migrations + Row Level Security on a throwaway Postgres
```
