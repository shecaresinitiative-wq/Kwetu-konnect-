# KWETU Development Checklist

Updated at the end of every block. Nothing is marked complete unless it works and was tested. Simulated is not production-ready.

_Last updated: Block 1, 9 Nov 2026._

## Completed (works and tested)

- [x] Splash screen (navy night-city skyline, wordmark, tagline, tap to enter)
- [x] Landing page, responsive
- [x] Design system tokens and shared components (navy, purple, turquoise)
- [x] App shell: header, town selector, 5-tab bottom navigation (side rail on desktop), Create menu
- [x] Registration with validation: name, email, Kenyan phone (+254 normalisation), 18+ date of birth, town, password
- [x] Login, logout, protected pages with safe redirect (no open redirects)
- [x] Profile: view, edit name / town / bio, account capabilities list
- [x] Home, Explore (category + text filter), Activity (empty-state notification centre)
- [x] Multi-town design: Bungoma is a config value, 8 towns seeded, neighbourhoods table ready
- [x] Terms, Privacy, Community guidelines pages (drafts, clearly labelled)
- [x] Database foundation: towns, neighbourhoods, profiles, profile_private, user_roles, audit_logs
- [x] Row Level Security: private data owner-only, no self-promotion, no self-suspension, audit log admin-only (tested on Postgres 16)
- [x] Server-side 18+ gate at sign-up (database trigger)
- [x] Demo mode, clearly labelled, so everything can be tested without a backend
- [x] Test suites: database/RLS, JS unit, site integrity, real-browser end to end

## Incomplete (planned, not built)

- [ ] Phone and email verification flows
- [ ] Avatar / cover upload (Supabase Storage)
- [ ] Posts, likes, comments, follows, the real home feed
- [ ] Create menu actions (post, service, experience, event, business) show "Soon"
- [ ] Companion and service provider profiles, availability, discovery
- [ ] Booking engine, double-booking prevention, queues
- [ ] Experiences and recurring activities
- [ ] Event publishing, ticket types, QR tickets, gate scanning, organiser dashboard
- [ ] Wellness listings, transport requests, messaging, reviews
- [ ] Notifications (real ones), notification preferences
- [ ] Admin dashboard and moderation queues
- [ ] "Around Me", "Same Venue", "Available Now" real data (sections show honest empty states; the two cards per section on Home are labelled SAMPLE)
- [ ] Location permission handling and consent-based sharing
- [ ] Neighbourhood data for each town (admins add as markets open)

## Supabase connection

- [x] Project "KWETU" created (Frankfurt); migrations 0001 + 0002 and the seed applied; URL and public key in `js/config.js`
- [x] Database rules verified on the REAL project (sign-up trigger, 18+ gate, private data, no self-promotion, function lockdown), inside a rolled-back transaction
- [x] Supabase adapter logic tested against a fake client
- [ ] In the Supabase dashboard, turn **Confirm email** off for testing (I cannot change this from here)
- [ ] **One real sign-up from the browser.** The sandbox cannot reach supabase.co, so the page-to-Supabase network call itself has not been exercised. Do one sign-up on your deployment and tell me what you see.
- [ ] Security advisor: `is_admin()` is intentionally callable by visitors (RLS policies need it; it only reports the caller's own status). Expect that one notice.

## Needs API credentials (later blocks)

- [ ] M-Pesa (Daraja) for real payments. Payments are designed as a pluggable provider with a labelled sandbox mode; none exist yet
- [ ] SMS provider for phone verification and notifications
- [ ] Email provider for transactional email (Supabase built-in is rate-limited)
- [ ] Push notifications

## Needs external verification

- [ ] Identity verification for companion providers, drivers, organisers and businesses (who verifies, and how, must be decided)
- [ ] Driver licence / vehicle checks for transport operators
- [ ] Wellness provider qualifications

## Needs legal or regulatory review before public launch

- [ ] **Companionship pillar**: Kenyan law on soliciting, brothel-keeping and living on earnings of sex work is strict, and platform liability is a real risk. Get advice from a Kenyan lawyer before building or launching this pillar. The product copy already states companionship is not a sexual service and payment is not consent, but copy is not a legal defence
- [ ] Terms of use, Privacy notice, Community guidelines (all placeholders today)
- [ ] Kenya Data Protection Act, 2019: registration with the Data Protection Commissioner, handling of location and ID data, retention
- [ ] Payments: holding customer funds needs a licensed provider (CBK-authorised). Do not run your own escrow
- [ ] Ticketing, commission and tax treatment (VAT, withholding)
- [ ] Transport: PSV / NTSA licensing rules for boda and private drivers
- [ ] Age-gating approach for adult features
- [ ] Company registration and business licences
